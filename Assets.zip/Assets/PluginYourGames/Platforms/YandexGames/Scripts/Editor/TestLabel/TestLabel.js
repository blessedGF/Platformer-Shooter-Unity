function hideTestLabel() {
		document.getElementById('test-label').style.display = 'none';
	}