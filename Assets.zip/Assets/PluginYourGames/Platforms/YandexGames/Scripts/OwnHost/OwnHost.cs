namespace YG.Insides
{
    public partial class PlatformInfo
    {
        [Platform("YandexGames")]
        public bool ownHost;
    }
}
