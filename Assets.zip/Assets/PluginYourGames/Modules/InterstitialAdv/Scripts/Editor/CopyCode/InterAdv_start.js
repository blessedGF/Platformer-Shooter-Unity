﻿setTimeout(function () {
    if (nowFullAdOpen == true)
        YG2Instance('OpenInterAdv');
}, 100);