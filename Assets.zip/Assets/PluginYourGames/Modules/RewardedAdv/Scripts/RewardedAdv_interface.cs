namespace YG
{
    public partial interface IPlatformsYG2
    {
        void RewardedAdvShow(string id) { }
        void LoadRewardedAdv() { }
    }
}