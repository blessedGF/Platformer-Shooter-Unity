namespace YG
{
    public partial interface IPlatformsYG2
    {
        void InitAuth() { }
        void GetAuth() { }
        void OpenAuthDialog() { }
    }
}