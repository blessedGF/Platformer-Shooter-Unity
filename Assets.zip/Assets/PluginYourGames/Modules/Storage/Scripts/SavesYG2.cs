﻿
namespace YG
{
    [System.Serializable]
    public partial class SavesYG
    {
        public int idSave;
    }
}
