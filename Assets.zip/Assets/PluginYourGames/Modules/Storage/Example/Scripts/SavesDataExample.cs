namespace YG
{
    public partial class SavesYG
    {
        public int intExample = 5;
        public string strExample = "Hello!";
        public bool[] boolExample = new bool[4];
    }
}