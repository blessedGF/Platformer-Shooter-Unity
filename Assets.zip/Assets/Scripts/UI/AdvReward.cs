using UnityEngine;
using YG;

public class AdvReward : MonoBehaviour
{
    [SerializeField] private string rewardID = "AdvRewardCoin";
    [SerializeField] private int rewardValue = 10;

    private void OnEnable()
    {
        YG2.onRewardAdv += OnReward;
    }
    private void OnDisable()
    {
        YG2.onRewardAdv -= OnReward;
    }
    public void RewardAdvShow(string id)
    {
        YG2.RewardedAdvShow(rewardID);
    }
    private void OnReward(string id)
    {
        if (id == rewardID)
        {
            CoinSystem.Instance.AddCoin(rewardValue);
        }
    }
}
