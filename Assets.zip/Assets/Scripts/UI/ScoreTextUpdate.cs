using TMPro;
using UnityEngine;

public class ScoreTextUpdate : MonoBehaviour
{
    public TextMeshPro scoreText { get; private set; }
    public static ScoreTextUpdate Instance { get; private set; }

    public delegate void OnChangeScoreText();
    public OnChangeScoreText ChangeScoreText;

    private void Awake()
    {
        if (Instance == null) { Instance = this; }

        scoreText = GetComponent<TextMeshPro>();
    }
    private void Start()
    {
        ChangeScoreText = TextUpdate;

        TextUpdate();
    }
    private void TextUpdate() 
    {
        string firstPlayerScore = RoundSystem.Instance.FirstPlayerScore.ToString();
        string secondPlayerScore = RoundSystem.Instance.SecondPlayerScore.ToString();

        scoreText.text = $"{firstPlayerScore} : {secondPlayerScore}";
    }
}
