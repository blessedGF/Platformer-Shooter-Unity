using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class FadeScreenEffect : MonoBehaviour
{
    private Image fadePanelImage;
    public Coroutine FadeCoroutine {  get; private set; }
    public static FadeScreenEffect Instance { get; private set; }

    private void Awake()
    {
        if (Instance == null) { Instance = this; }

        fadePanelImage = GetComponent<Image>();
    }
    private void Start()
    {
        StartFadeEffect(0f, 1.5f);
    }
    public void StartFadeEffect(float targetValue, float fadePanelSpeedChange = 1f, Action onComplete = null)
    {
        if (FadeCoroutine != null) { return; }

        FadeCoroutine = StartCoroutine(FadeEffect(targetValue, fadePanelSpeedChange, onComplete));
    }
    private IEnumerator FadeEffect(float targetValue, float fadePanelSpeedChange = 1f, Action onComplete = null) 
    {
        fadePanelImage.fillAmount = 1 - targetValue;

        while (fadePanelImage.fillAmount != targetValue)
        {
            fadePanelImage.fillAmount = Mathf.MoveTowards(fadePanelImage.fillAmount, targetValue, Time.deltaTime * fadePanelSpeedChange);

            yield return null;
        }

        onComplete?.Invoke();

        FadeCoroutine = null;
    }
}
