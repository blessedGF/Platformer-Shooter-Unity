using UnityEngine;
using UnityEngine.Localization;
using UnityEngine.Localization.Components;

public class ResetToDefaultString : MonoBehaviour
{
    private LocalizeStringEvent localizeStringEvent;
    private LocalizedString defaultString;
    private void Awake()
    {
        localizeStringEvent = GetComponent<LocalizeStringEvent>();
        defaultString = localizeStringEvent.StringReference;
    }
    private void OnEnable()
    {
        localizeStringEvent.StringReference = defaultString;
    }
}
