using System;
using System.Collections;
using TMPro;
using UnityEngine;

public class HealCountEffect : MonoBehaviour
{
    [SerializeField] private float durationTime = 1f;
    [SerializeField] private float disappearanceTime = 1f;
    [SerializeField] private TextMeshPro healText;

    [NonSerialized] public float _heal;
    private float Heal => _heal;
    private void Start()
    {
        StartCoroutine(HealEffect(Heal, new Vector2(UnityEngine.Random.Range(0f, 1f), UnityEngine.Random.Range(0f, 1f))));
    }
    private IEnumerator HealEffect(float _healValue, Vector2 direction)
    {
        healText.text = $"+{_healValue}";

        float alpha = healText.color.a;

        while (healText.color.a > 0)
        {
            alpha -= Time.deltaTime * disappearanceTime;
            Color targetColor = new Color(healText.color.r, healText.color.g, healText.color.b, alpha);
            healText.color = targetColor;

            healText.transform.localPosition = Vector2.Lerp(healText.transform.localPosition, direction, Time.deltaTime * durationTime);

            yield return null;
        }

        Destroy(gameObject);
    }
}
