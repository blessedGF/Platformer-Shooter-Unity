using UnityEngine;

public class PunchDroppedWeapon : MonoBehaviour
{
    [SerializeField] private float punchPowerValue = 200f;
    [SerializeField] private float rotatePowerValue = 200f;

    public Vector2 punchVector;

    private Rigidbody2D weaponRigidbody;
    private void Start()
    {
        weaponRigidbody = GetComponent<Rigidbody2D>();
        weaponRigidbody.AddForce(punchVector * punchPowerValue, ForceMode2D.Impulse);
        weaponRigidbody.AddTorque(rotatePowerValue, ForceMode2D.Impulse);

        Destroy(gameObject, 5f);
    }
}
