using UnityEngine;

public interface IBullet
{
    public float bulletSpeed { get; set; }
    public float bulletDamage { get; set; }
    public GameObject bulletOwner { get; set; }
}
