using System.Collections.Generic;
using UnityEngine;

public class RandomWeapon : MonoBehaviour
{
    private WeaponData[] weaponList;
    private Weapon weaponData;

    private void Awake()
    {
        weaponList = Resources.LoadAll<WeaponData>("Weapons");
    }
    private void Start()
    {
        weaponData = GetComponent<Weapon>();

        List<WeaponData> unlockedWeaponList = new List<WeaponData>();

        foreach(var weapon in weaponList)
        {
            if (!weapon.isLocked)
            {
                unlockedWeaponList.Add(weapon);
            }
        }

        if (unlockedWeaponList.Count > 0)
        {
            weaponData._weapon = unlockedWeaponList[Random.Range(0, unlockedWeaponList.Count)];
        }
    }
}