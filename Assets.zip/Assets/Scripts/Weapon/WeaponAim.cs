using UnityEngine;
using static UnityEngine.UI.Image;

public class WeaponAim : MonoBehaviour
{
    [SerializeField] private PlayerLookDirectional playerLookDirectional;
    [SerializeField] private PlayerController playerController;
    [SerializeField] private float aimSpeed = 1f;
    public bool AimOnPlayer { get; private set; }

    private LayerMask layer;
    private Transform target;

    private void Start()
    {
        FindTarget();
        GetLayerMask();
    }
    private void Update()
    {
        ChangeWeaponDirectional();
    }
    private void GetLayerMask()
    {
        layer = playerController.IsFirstPlayer ? ~LayerMask.GetMask("FirstPlayer") : ~LayerMask.GetMask("SecondPlayer");
    }

    private void FindTarget()
    {
        GameObject[] targets = GameObject.FindGameObjectsWithTag("Player");

        foreach (GameObject player in targets) 
        {
            if (player.transform != transform.root) 
            {
                target = player.transform;
            }
        }
    }
    private void ChangeWeaponDirectional()
    {
        if (playerLookDirectional != null)
        {
            if (target != null) 
            {
                Vector2 direction = playerLookDirectional.LeftDirectional ? transform.position - target.position : target.position - transform.position;

                direction.Normalize();

                float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;

                RaycastHit2D hit = Physics2D.Raycast(transform.position, target.position - transform.position, Mathf.Infinity, layer);

                float xRotation = playerLookDirectional.LeftDirectional ? 180f : 0f;

                float _angle = playerLookDirectional.LeftDirectional ? angle + 180 : angle;
                Quaternion targetRot = angle < -90f || angle > 90f ? Quaternion.Euler(0f, 0f, xRotation) : hit.transform == target ? Quaternion.Euler(0, 0, _angle) : Quaternion.Euler(0f, 0f, xRotation);
                transform.rotation = Quaternion.Lerp(transform.rotation, targetRot, Time.deltaTime * aimSpeed);

                float scaleValue = playerLookDirectional.LeftDirectional ? -1f : 1f;
                transform.localScale = new Vector3(1f, scaleValue, 1f);

                RaycastHit2D weaponHit = Physics2D.Raycast(transform.position, transform.TransformDirection(Vector2.right), Mathf.Infinity, layer);

                AimOnPlayer = weaponHit.transform == target;
            }
            else
            {
                float xRotation = playerLookDirectional.LeftDirectional ? 180f : 0f;
                transform.rotation = Quaternion.Lerp(transform.rotation, Quaternion.Euler(0f, 0f, xRotation), Time.deltaTime * aimSpeed);

                float scaleValue = playerLookDirectional.LeftDirectional ? -1f : 1f;
                transform.localScale = new Vector3(1f, scaleValue, 1f);
            }
        }
    }
}