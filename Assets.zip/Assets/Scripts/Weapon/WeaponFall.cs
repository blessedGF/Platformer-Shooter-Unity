using UnityEngine;

public class WeaponFall : MonoBehaviour
{
    private float fallingSpeed = 1f;
    private void Update()
    {
        transform.Translate(Vector2.down * Time.deltaTime * fallingSpeed);
    }
}
