using DG.Tweening;
using EZCameraShake;
using System;
using UnityEngine;

public class WeaponSystem : MonoBehaviour
{
    [SerializeField] private PlayerLookDirectional playerLookDirectional;
    [SerializeField] private Transform weaponSlot;
    [SerializeField] private GameObject droppedWeaponPrefab;
    [SerializeField] private WeaponAim weaponAim;
    [SerializeField] private AudioClip refillAmmoSound;
    [SerializeField] private bool autoAttack;

    private PlayerController playerController;
    private InputState inputState;
    private InputManager inputManager;
    private AudioSource audioSource;
    private Rigidbody2D playerRigidbody;
    private PlayerHealth playerHealth;

    private float fireDelay = 0f;

    private GameObject weaponObject;

    public event Action OnAmmoUpdate;
    public WeaponData weaponData { get; private set; }
    public int currentAmmoValue { get; private set; }

    private void Awake()
    {
        playerController = GetComponent<PlayerController>();
        audioSource = GetComponent<AudioSource>();
        playerRigidbody = GetComponent<Rigidbody2D>();
        inputState = GetComponent<InputState>();
        inputManager = GetComponent<InputManager>();
        playerHealth = GetComponent<PlayerHealth>();

        playerHealth.OnDead += DropWeapon;
    }
    private void OnDisable()
    {
        playerHealth.OnDead -= DropWeapon;
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Weapon"))
        {
            if (weaponData != null)
            {
                DropWeapon();
            }

            WeaponData collisionWeaponData = collision.GetComponent<Weapon>().WeaponData;

            TakeWeapon(collisionWeaponData);

            Destroy(collision.gameObject);
        }
        else if (collision.CompareTag("Ammo"))
        {
            RefillAmmo(collision.gameObject);
        }
    }
    private void Update()
    {
        FireWeapon();
    }
    private void FireWeapon()
    {
        if (inputState.MoveIsLocked) { return; }

        if (weaponData != null)
        {
            if (autoAttack)
            {
                if (weaponAim.AimOnPlayer) { Shot(); }
            }
            else
            {
                if (inputManager.FireInput > 0f) { Shot(); }
            }

            if (fireDelay > 0)
            {
                fireDelay -= Time.deltaTime;
                fireDelay = Mathf.Clamp(fireDelay, 0, weaponData.firingRate);
            }
        }
    }
    private void Shot()
    {
        if (currentAmmoValue > 0)
        {
            if (fireDelay == 0f)
            {
                currentAmmoValue--;
                OnAmmoUpdate?.Invoke();

                Transform spawnPos = weaponObject.GetComponent<BulletSpawnPosData>().bulletSpawnPos;
                int layer = gameObject.layer;
                string layerName = LayerMask.LayerToName(layer);
                LayerMask layerMask = LayerMask.GetMask(layerName);

                float spreadAngle = weaponData.weaponSpreadAngle;

                for (int i = 0; i < weaponData.bulletCount; i++)
                {
                    float randomAngle = UnityEngine.Random.Range(-spreadAngle / 2f, spreadAngle / 2f);
                    Quaternion bulletRotation = weaponSlot.rotation * Quaternion.Euler(0, 0, randomAngle);
                    CreateBullet(weaponData, spawnPos.position, bulletRotation, layerMask, gameObject);
                }

                fireDelay = weaponData.firingRate;

                Vector2 targetForce = playerLookDirectional.LeftDirectional ? Vector2.right : Vector2.left;
                playerRigidbody.AddForce(targetForce * weaponData.weaponPlayerRecoil, ForceMode2D.Impulse);

                float moveValue = playerLookDirectional.LeftDirectional ? weaponData.weaponRecoil : -weaponData.weaponRecoil;
                weaponSlot.DOLocalMoveX(moveValue, 0.1f).OnComplete(() => { weaponSlot.DOLocalMoveX(0f, 0.2f); });

                CameraShaker.Instance.ShakeOnce(2f, 4f, 0.2f, 0.2f);

                audioSource.PlayOneShot(weaponData.weaponShotSound);
            }
        }
        else
        {
            if (fireDelay == 0f)
            {
                fireDelay = weaponData.firingRate;
                audioSource.PlayOneShot(weaponData.emptySound);
            }
        }
    }
    private void CreateBullet(WeaponData weaponData, Vector3 position, Quaternion rotation, LayerMask excludeLayer, GameObject owner)
    {
        GameObject bullet = Instantiate(weaponData.bulletPrefab, position, rotation);

        Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();
        Collider2D col = bullet.GetComponent<Collider2D>();

        IBullet bulletMove = bullet.GetComponent<IBullet>();

        rb.excludeLayers = excludeLayer;
        col.excludeLayers = excludeLayer;

        bulletMove.bulletDamage = weaponData.damage;
        bulletMove.bulletSpeed = weaponData.bulletSpeed;
        bulletMove.bulletOwner = owner;
    }
    private void TakeWeapon(WeaponData _weaponData)
    {
        if (_weaponData == null) { return; }

        weaponData = _weaponData;

        currentAmmoValue = _weaponData.maxAmmo;
        OnAmmoUpdate?.Invoke();

        GameObject newWeaponObject = Instantiate(_weaponData.handWeaponPrefab, weaponSlot);
        newWeaponObject.GetComponent<WeaponShake>()._playerController = playerController;
        weaponObject = newWeaponObject;

        audioSource.PlayOneShot(_weaponData.pickupSound);
    }
    private void DropWeapon(GameObject _player = null)
    {
        if (weaponData == null) { return; }

        if (weaponSlot.childCount != 0)
        {
            GameObject newDroppedWeapon = Instantiate(droppedWeaponPrefab, transform.position, Quaternion.identity);
            newDroppedWeapon.GetComponent<SpriteRenderer>().sprite = weaponData.weaponImage;
            newDroppedWeapon.GetComponent<PunchDroppedWeapon>().punchVector = playerLookDirectional.LeftDirectional ? Vector2.left : Vector2.right;

            GameObject parentChild = weaponSlot.GetChild(0).gameObject;
            Destroy(parentChild);
        }

        weaponObject = null;

        weaponData = null;
    }
    private void RefillAmmo(GameObject refillBox) 
    {
        if (weaponData == null) { return; }

        currentAmmoValue = weaponData.maxAmmo;

        audioSource.PlayOneShot(refillAmmoSound);

        Destroy(refillBox);
    }
}
