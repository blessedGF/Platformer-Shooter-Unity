using System;
using UnityEngine;

public class WeaponShake : MonoBehaviour
{
    [SerializeField] private float swayAmount = 0.1f; 
    [SerializeField] private float swaySpeed = 5f;
    [SerializeField] private float returnSpeed = 2f; 

    [NonSerialized] public PlayerController _playerController;
    public PlayerController PlayerController => _playerController;

    private Vector3 initialLocalPosition;
    private float swayTimer = 0f;

    private void Start()
    {
        initialLocalPosition = transform.localPosition;
    }

    private void Update()
    {
        bool isMoving = PlayerController.MoveInput != 0f;

        if (isMoving)
        {
            swayTimer += Time.deltaTime * swaySpeed;
            float swayY = Mathf.Sin(swayTimer) * swayAmount;
            transform.localPosition = initialLocalPosition + new Vector3(0f, swayY, 0f);
        }
        else
        {
            transform.localPosition = Vector3.Lerp(transform.localPosition, initialLocalPosition, Time.deltaTime * returnSpeed);

            swayTimer = 0f;
        }
    }
}
