using UnityEngine;

public class Weapon : MonoBehaviour
{
    public WeaponData _weapon;
    public WeaponData WeaponData => _weapon;
}
