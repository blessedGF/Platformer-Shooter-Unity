using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class ChanceSpawnableObject
{
    public GameObject spawnableObject;
    [Range(0, 100)] public float percentage;
}

public class WeaponSpawner : MonoBehaviour
{
    [Header("Spawner Parameters")]
    [SerializeField] private float spawnRate = 5f;
    [SerializeField] private float spawnRadius = 10f;
    [SerializeField] private float destroyTime = 15f;
    [Space]
    [SerializeField] private List<ChanceSpawnableObject> spawnableObjects;
    [SerializeField] private InitializePlayer initializePlayer;

    private float _totalWeight;

    private void Start()
    {
        CalculateWeights();
        InvokeRepeating(nameof(SpawnRandomWeapon), 1, spawnRate);
    }

    private void CalculateWeights()
    {
        _totalWeight = 0f;
        foreach (var obj in spawnableObjects)
        {
            _totalWeight += obj.percentage;
        }
    }

    private void SpawnRandomWeapon()
    {
        if (initializePlayer != null)
        {
            if (!initializePlayer.GameIsStarted) return;
        }

        float randomPosX = UnityEngine.Random.Range(-spawnRadius, spawnRadius);
        Vector2 spawnPosition = new Vector2(transform.position.x + randomPosX, transform.position.y);

        GameObject weaponToSpawn = GetWeightedRandomObject();
        if (weaponToSpawn == null) return;

        GameObject newSpawnedWeapon = Instantiate(weaponToSpawn, spawnPosition, Quaternion.identity);
        Destroy(newSpawnedWeapon, destroyTime);
    }

    private GameObject GetWeightedRandomObject()
    {
        if (spawnableObjects.Count == 0) return null;

        float randomValue = UnityEngine.Random.Range(0f, _totalWeight);
        float currentWeight = 0f;

        foreach (var obj in spawnableObjects)
        {
            currentWeight += obj.percentage;
            if (randomValue <= currentWeight)
            {
                return obj.spawnableObject;
            }
        }

        return spawnableObjects[0].spawnableObject;
    }

    private void OnValidate()
    {
        if (spawnableObjects != null)
        {
            foreach (var obj in spawnableObjects)
            {
                if (obj.percentage < 0) obj.percentage = 0;
            }
        }
    }
}