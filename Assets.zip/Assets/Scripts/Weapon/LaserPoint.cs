using UnityEngine;

[RequireComponent(typeof(LineRenderer))]
public class LaserPoint : MonoBehaviour
{
    [SerializeField] private float maxDistance = 10f;
    [SerializeField] private LayerMask collisionLayer;

    private LineRenderer lineRenderer;

    private void Start()
    {
        lineRenderer = GetComponent<LineRenderer>();
        lineRenderer.positionCount = 2;
        lineRenderer.startColor = new Color(1f, 0f, 0f, 0.75f);
        lineRenderer.endColor = new Color(1f, 0f, 0f, 0.75f);
    }

    private void Update()
    {
        UpdateLine();
    }

    private void UpdateLine()
    {
        float angle = transform.parent.parent.eulerAngles.z * Mathf.Deg2Rad;
        Vector2 direction = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle)).normalized;

        Vector2 startPoint = transform.position;

        RaycastHit2D hit = Physics2D.Raycast(startPoint, direction, maxDistance, collisionLayer);

        Vector2 endPoint;
        if (hit.collider != null)
        {
            endPoint = hit.point;
        }
        else
        {
            endPoint = startPoint + direction * maxDistance;
        }

        lineRenderer.SetPosition(0, startPoint);
        lineRenderer.SetPosition(1, endPoint);

        Debug.DrawRay(startPoint, direction * maxDistance, Color.green);
    }
}