using UnityEngine;
using UnityEngine.Localization;

[CreateAssetMenu()]
public class WeaponData : ScriptableObject
{
    public string uniqueId;
    public float damage;
    public float bulletSpeed;
    public float firingRate;
    public float weaponPlayerRecoil;
    public float weaponRecoil;
    public int bulletCount;
    public float weaponSpreadAngle;
    public int maxAmmo;
    public GameObject handWeaponPrefab;
    public GameObject weaponPrefab;
    public GameObject bulletPrefab;
    public AudioClip weaponShotSound;
    public AudioClip emptySound;
    public AudioClip pickupSound;
    public Sprite weaponImage;
    public float weaponImageSize;
    public LocalizedString localeWeaponName;
    public int coinPriceValue;
    public int gemPriceValue;
    public bool isLocked;
    public bool unlockedByDefault;
}
