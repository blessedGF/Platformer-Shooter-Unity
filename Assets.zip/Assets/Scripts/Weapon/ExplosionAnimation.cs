using System.Collections;
using UnityEngine;

public class ExplosionAnimation : MonoBehaviour
{
    [SerializeField] private AudioSource audioSource;
    [SerializeField] private AudioClip explosionSound;
    [SerializeField] private SpriteRenderer explosionImage;
    [SerializeField] private Sprite[] explosionSprites;
    [SerializeField] private float timeToNextSprite = 0.1f;
    [SerializeField] private float timeToDestroy = 5f;
    private void Start()
    {
        StartCoroutine(ExplosionAnimationCoroutine());
    }
    private IEnumerator ExplosionAnimationCoroutine()
    {
        audioSource.PlayOneShot(explosionSound);

        explosionImage.transform.localScale = Vector3.one * 10f;

        for (int i = 0; i < explosionSprites.Length; i++)
        {
            explosionImage.sprite = explosionSprites[i];
            yield return new WaitForSeconds(timeToNextSprite);
        }

        Destroy(gameObject, timeToDestroy);
    }
}
