using UnityEngine;

public class BulletMove : MonoBehaviour, IBullet
{
    [SerializeField] private float timeToDestroy = 10f;
    public float bulletSpeed { get; set; }
    public float bulletDamage { get; set; }
    public GameObject bulletOwner { get; set; }

    public float BulletSpeed => bulletSpeed;
    public float BulletDamage => bulletDamage;
    public GameObject BulletOwner => bulletOwner;

    private Rigidbody2D bulletRigidbody;

    private void Start()
    {
        bulletRigidbody = GetComponent<Rigidbody2D>();
        bulletRigidbody.velocity = transform.right * BulletSpeed;

        Destroy(gameObject, timeToDestroy);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.transform.CompareTag("Bullet")) { return; }

        IHealth health = collision.transform.GetComponent<IHealth>();

        health?.RemoveHealth(BulletDamage, BulletOwner);

        Destroy(gameObject);
    }
}