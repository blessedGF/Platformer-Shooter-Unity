using EZCameraShake;
using UnityEngine;

public class RpgBulletMove : MonoBehaviour, IBullet
{
    [Header("Explosion Settings")]
    [SerializeField] private float timeToDestroy = 10f;
    [SerializeField] private GameObject explosionPrefab;
    [SerializeField] private float explosionRadius = 3f;
    [SerializeField] private LayerMask obstacleLayer;
    [SerializeField] private LayerMask playerLayer;

    [Header("Camera Shake")]
    [SerializeField] private float shakeMagnitude = 3f;
    [SerializeField] private float shakeRoughness = 4f;
    [SerializeField] private float shakeFadeIn = 0.2f;
    [SerializeField] private float shakeFadeOut = 0.2f;

    public float bulletSpeed { get; set; }
    public float bulletDamage { get; set; }
    public GameObject bulletOwner { get; set; }

    private Rigidbody2D bulletRigidbody;

    private void Start()
    {
        bulletRigidbody = GetComponent<Rigidbody2D>();
        bulletRigidbody.velocity = transform.right * bulletSpeed;
        Destroy(gameObject, timeToDestroy);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.CompareTag("Bullet"))
            return;

        CreateExplosion();
        Destroy(gameObject);
    }

    private void CreateExplosion()
    {
        Instantiate(explosionPrefab, transform.position, Quaternion.identity);
        CameraShaker.Instance.ShakeOnce(shakeMagnitude, shakeRoughness, shakeFadeIn, shakeFadeOut);

        Collider2D[] hitColliders = Physics2D.OverlapCircleAll(
            transform.position,
            explosionRadius,
            playerLayer
        );

        foreach (Collider2D col in hitColliders)
        {
            if (!col.CompareTag("Player")) continue;

            IHealth health = col.GetComponent<IHealth>();
            if (health == null) continue;

            if (!IsObstacleBetween(col.transform))
            {
                health.RemoveHealth(bulletDamage, bulletOwner);
            }
        }
    }

    private bool IsObstacleBetween(Transform target)
    {
        Vector2 direction = (target.position - transform.position).normalized;
        float distance = Vector2.Distance(transform.position, target.position);

        Vector2 origin = (Vector2)transform.position + direction * 0.1f;

        RaycastHit2D hit = Physics2D.Raycast(
            origin,
            direction,
            distance - 0.1f,
            obstacleLayer
        );

        Debug.DrawRay(origin, direction * (distance - 0.1f),
                     hit.collider ? Color.red : Color.green, 1f);

        return hit.collider != null;
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, explosionRadius);
    }
}