using UnityEngine;

public class BulletSpawnPosData : MonoBehaviour
{
    public Transform bulletSpawnPos;
}
