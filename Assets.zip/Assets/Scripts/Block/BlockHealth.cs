using System;
using UnityEngine;

public class BlockHealth : MonoBehaviour, IHealth
{
    [SerializeField] private float setMaxHealth = 100f;
    [SerializeField] private GameObject deathPrefab;
    public float currentHealth { get; set; }
    public float maxHealth { get; set; }
    public bool isDead { get; set; } = false;

    public event Action<GameObject> OnDead;
    public event Action<float> OnHit;

    private void Start()
    {
        maxHealth = setMaxHealth;
        currentHealth = maxHealth;
    }
    public void RemoveHealth(float value, GameObject attacker)
    {
        if (value <= 0) { return; }

        OnHit?.Invoke(value);

        if (currentHealth > 0f)
        {
            if (currentHealth - value > 0f)
            {
                currentHealth -= value;
            }
            else
            {
                BlockRemove(attacker);
            }
        }
    }
    public void AddHealth(float value)
    {
        if (value <= 0) { return; }

        if (currentHealth > 0f)
        {
            if (currentHealth + value < maxHealth)
            {
                currentHealth += value;
            }
            else
            {
                currentHealth = maxHealth;
            }
        }
    }
    private void BlockRemove(GameObject killerPlayer)
    {
        currentHealth = 0f;
        isDead = true;

        OnDead?.Invoke(killerPlayer);

        Instantiate(deathPrefab, transform.position, Quaternion.identity);

        Destroy(gameObject);
    }
}
