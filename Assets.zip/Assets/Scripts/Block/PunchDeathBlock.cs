using UnityEngine;

public class PunchDeathBlock : MonoBehaviour
{
    [SerializeField] private float rotatePowerValue = 200f;

    private Rigidbody2D blockRigidbody;
    private void Start()
    {
        blockRigidbody = GetComponent<Rigidbody2D>();
        blockRigidbody.AddTorque(rotatePowerValue, ForceMode2D.Impulse);

        Destroy(gameObject, 5f);
    }
}