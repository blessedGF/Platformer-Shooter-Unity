using System.Collections;
using UnityEngine;

public class MainMenuPanels : MonoBehaviour
{
    [SerializeField] private GameObject[] panels;

    private Coroutine showPanelCoroutine;
    public static MainMenuPanels Instance { get; private set; }

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
    }

    public void ShowPanel(int index)
    {
        if (showPanelCoroutine != null) { return; }

        FadeScreenEffect.Instance.StartFadeEffect(1f, 1.5f, () =>
        {
            foreach (var panel in panels) panel.SetActive(false);
            panels[index].SetActive(true);

            showPanelCoroutine = StartCoroutine(DelayedFade());
        });
    }
    private IEnumerator DelayedFade()
    {
        yield return new WaitForSeconds(0.5f); 

        FadeScreenEffect.Instance.StartFadeEffect(0f, 1.5f, () =>
        {
            showPanelCoroutine = null;
        }); 
    }

    public void Quit() => Application.Quit();
}