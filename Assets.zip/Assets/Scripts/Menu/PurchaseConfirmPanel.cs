using DG.Tweening;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.Localization.Components;
using UnityEngine.UI;

public class PurchaseConfirmPanel : MonoBehaviour
{
    [SerializeField] private Button purchaseButton;
    [SerializeField] private TextMeshProUGUI noMoneyText;
    [SerializeField] private LocalizeStringEvent purchaseConfirmPanelText;
    [SerializeField] private GameObject confirmPanel;
    [SerializeField] private Image confirmPanelImage;
    [Header("Animation settings")]
    [SerializeField] private float fadeDuration = 1f;
    [SerializeField] private float moveDuration = 1f;
    [SerializeField] private float panelPosX = -2000f;

    private float startAlpha;
    private bool panelIsOpen;

    private WeaponData weaponData;
    private SkinData skinData;
    public static PurchaseConfirmPanel Instance { get; private set; }
    private void Awake()
    {
        startAlpha = confirmPanelImage.color.a;
    }
    private void OnEnable()
    {
        if (Instance == null) { Instance = this; }

        StartCoroutine(CheckInitializeShopSystem());
    }
    private void OnDisable()
    {
        ShopSystem.Instance.OnPurchase -= CloseConfirmPanel;
    }
    public void OpenConfirmPanel(SkinData skin)
    {
        UpdateConfirmPanelInfo(skin);

        OpenAnimationPanel();
    }
    public void OpenConfirmPanel(WeaponData weapon)
    {
        UpdateConfirmPanelInfo(weapon);

        OpenAnimationPanel();
    }
    private void OpenAnimationPanel()
    {
        if (panelIsOpen) { return; }

        panelIsOpen = true;

        confirmPanel.transform.localPosition = new Vector3(panelPosX, 0f, 0f);
        confirmPanelImage.color = new Color(0f, 0f, 0f, 0f);

        confirmPanelImage.gameObject.SetActive(true);

        confirmPanelImage.DOFade(startAlpha, fadeDuration);
        confirmPanel.transform.DOLocalMoveX(0f, moveDuration);
    }
    private void CloseAnimationPanel()
    {
        if (!panelIsOpen) { return; }

        panelIsOpen = false;

        confirmPanelImage.DOFade(0f, fadeDuration);
        confirmPanel.transform.DOLocalMoveX(panelPosX * -1f, moveDuration).OnComplete(() => 
        {
            confirmPanelImage.gameObject.SetActive(false);
        });
    }
    public void CloseConfirmPanel()
    {
        CloseAnimationPanel();

        weaponData = null;
        skinData = null;

        purchaseButton.interactable = true;
        noMoneyText.gameObject.SetActive(false);
        purchaseButton.onClick.AddListener(() => { });
    }
    private void UpdateConfirmPanelInfo(SkinData skin)
    {
        skinData = skin;

        bool playerHaveMoney = skin.coinPriceValue <= CoinSystem.Instance.CurrentCoinValue && skin.gemPriceValue <= CoinSystem.Instance.CurrentGemValue;

        purchaseConfirmPanelText.StringReference.Arguments = new object[] { skin.nameLocalizationKey.GetLocalizedString() };
        purchaseConfirmPanelText.RefreshString();

        purchaseButton.interactable = playerHaveMoney;
        noMoneyText.gameObject.SetActive(!playerHaveMoney);

        purchaseButton.onClick.AddListener(() => 
        {
            ShopSystem.Instance.PurchaseItem(skinData);
        });
    }
    private void UpdateConfirmPanelInfo(WeaponData weapon)
    {
        weaponData = weapon;

        bool playerHaveMoney = weapon.coinPriceValue <= CoinSystem.Instance.CurrentCoinValue && weapon.gemPriceValue <= CoinSystem.Instance.CurrentGemValue;

        purchaseConfirmPanelText.StringReference.Arguments = new object[] { weapon.localeWeaponName.GetLocalizedString() };
        purchaseConfirmPanelText.RefreshString();

        purchaseButton.interactable = playerHaveMoney;
        noMoneyText.gameObject.SetActive(!playerHaveMoney);

        purchaseButton.onClick.AddListener(() =>
        {
            ShopSystem.Instance.PurchaseItem(weaponData);
        });
    }
    private IEnumerator CheckInitializeShopSystem()
    {
        while (ShopSystem.Instance == null)
        {
            yield return null;
        }

        ShopSystem.Instance.OnPurchase += CloseConfirmPanel;
    }
}
