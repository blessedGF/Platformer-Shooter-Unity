using UnityEngine;

public class InitializeAllTutorialWeapon : MonoBehaviour
{
    [SerializeField] private GameObject tutorialWeaponPrefab;
    [SerializeField] private Transform tutorialWeaponParent;

    private WeaponData[] allWeapon;

    private void Start()
    {
        allWeapon = Resources.LoadAll<WeaponData>("Weapons");

        for (int i = 0; i < allWeapon.Length; i++)
        {
            int currentIndex = i;
            GameObject tutorialWeapon = Instantiate(tutorialWeaponPrefab, tutorialWeaponParent);

            TutorialWeaponData tutorialWeaponData = tutorialWeapon.GetComponent<TutorialWeaponData>();

            tutorialWeaponData.TutorialWeaponButton.onClick.AddListener(() =>
            {
                UpdateWeaponInfoPanel(allWeapon[currentIndex]);
            });

            tutorialWeaponData.TutorialWeaponNameText.StringReference = allWeapon[currentIndex].localeWeaponName;
        }
    }

    public void UpdateWeaponInfoPanel(WeaponData weaponData)
    {
        TutorialWeaponUpdateInfo.Instance.UpdateInfo(weaponData);
    }
}