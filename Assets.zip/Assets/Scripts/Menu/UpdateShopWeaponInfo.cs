using TMPro;
using UnityEngine;
using UnityEngine.Localization.Components;
using UnityEngine.UI;

public class UpdateShopWeaponInfo : MonoBehaviour
{
    [SerializeField] private Image weaponImage;
    [SerializeField] private LocalizeStringEvent nameLocalizeStringEvent;
    [SerializeField] private TextMeshProUGUI weaponPriceText;
    [SerializeField] private GameObject weaponCoinImage;
    [SerializeField] private GameObject weaponGemImage;
    [SerializeField] private GameObject purchasedImage;
    [SerializeField] private GameObject freeText;
    [SerializeField] private Button purchaseButton;
    public WeaponData WeaponData { get; private set; }

    public delegate void UpdateWeaponInfo();
    public UpdateWeaponInfo OnUpdateShopWeaponInfo { get; private set; }

    public delegate void SetShopWeaponData(WeaponData _weaponData);
    public SetShopWeaponData OnSetShopWeaponData { get; private set; }

    private void OnEnable()
    {
        OnSetShopWeaponData = SetWeaponData;

        ShopSystem.Instance.OnPurchase += UpdateInfo;
    }
    private void OnDisable()
    {
        ShopSystem.Instance.OnPurchase -= UpdateInfo;
    }
    private void SetWeaponData(WeaponData _weaponData)
    {
        WeaponData = _weaponData;

        UpdateInfo();
    }
    private void UpdateInfo()
    {
        weaponImage.sprite = WeaponData.weaponImage;

        bool itemIsFree = WeaponData.coinPriceValue <= 0 && WeaponData.gemPriceValue <= 0;

        weaponCoinImage.SetActive(WeaponData.coinPriceValue > 0);
        weaponGemImage.SetActive(WeaponData.gemPriceValue > 0);

        string coinText = (WeaponData.coinPriceValue > 0) ? $"<color=#FFAD00>{WeaponData.coinPriceValue}</color>" : "";
        string gemText = (WeaponData.gemPriceValue > 0) ? $"<color=#73B5FF>{WeaponData.gemPriceValue}</color>" : "";

        weaponPriceText.text = (WeaponData.coinPriceValue > 0 && WeaponData.gemPriceValue > 0)
        ? $"{coinText} {gemText}"
        : $"{coinText}{gemText}";

        freeText.SetActive(itemIsFree);

        if (WeaponData.weaponImage != null)
        {
            RectTransform imageRect = weaponImage.GetComponent<RectTransform>();

            imageRect.localScale = Vector3.one * WeaponData.weaponImageSize;
            imageRect.sizeDelta = new Vector2(
                WeaponData.weaponImage.texture.width,
                WeaponData.weaponImage.texture.height
            );
            weaponImage.preserveAspect = true;
        }

        nameLocalizeStringEvent.StringReference = WeaponData.localeWeaponName;
        nameLocalizeStringEvent.RefreshString();

        purchasedImage.SetActive(!WeaponData.isLocked);

        purchaseButton.onClick.AddListener(() =>
        {
            if (WeaponData.isLocked)
            {
                PurchaseConfirmPanel.Instance.OpenConfirmPanel(WeaponData);
            }
            else
            {
                Debug.Log("Weapon is purchased!");
            }
        });
    }
}
