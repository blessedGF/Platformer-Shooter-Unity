using DG.Tweening;
using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using YG;

[System.Serializable]
public class DailyReward
{
    public int coinCount;
    public int gemCount;
    public bool isReceived;
}

public class DailyRewardSystem : MonoBehaviour
{
    [SerializeField] private GameObject dailyRewardPanel;
    [SerializeField] private GameObject dailyRewardList;
    [SerializeField] private GameObject dailyRewardPrefab;
    [SerializeField] private Transform dailyRewardParent;
    [SerializeField] private DailyReward[] dailyRewards;
    [SerializeField] private TextMeshProUGUI timerText;
    [Header("Animation settings")]
    [SerializeField] private float colorFadeDuration = 1f;
    [SerializeField] private float moveDuration = 1f;
    [SerializeField] private float panelPosY = 1000f;

    public int CurrentRewardDays { get; private set; } = 1;
    public bool DailyRewardPanelIsActive { get; private set; }

    private float panelStartAlpha;
    private DateTime lastClaimDateTime;
    private bool refreshedAfterUnlock = false;

    public static DailyRewardSystem Instance { get; private set; }

    private void Awake()
    {
        if (Instance == null)
            Instance = this;

        panelStartAlpha = dailyRewardPanel.GetComponent<Image>().color.a;
    }

    private void Start()
    {
        LoadProgress();
        RefreshRewardUI();
        InvokeRepeating(nameof(UpdateTimer), 0f, 1f);
    }

    private void InitializeDailyReward()
    {
        for (int i = 0; i < dailyRewards.Length; i++)
        {
            int day = i + 1;
            int coinRewardValue = dailyRewards[i].coinCount;
            int gemRewardValue = dailyRewards[i].gemCount;
            int currentIndex = i;
            bool lockState = day > CurrentRewardDays;

            GameObject newDailyRewardPrefab = Instantiate(dailyRewardPrefab, dailyRewardParent);
            DailyRewardPrefab dailyRewardComponents = newDailyRewardPrefab.GetComponent<DailyRewardPrefab>();

            dailyRewardComponents.CoinImage.SetActive(coinRewardValue > 0);
            dailyRewardComponents.GemImage.SetActive(gemRewardValue > 0);
            dailyRewardComponents.RewardButton.interactable = !lockState && !dailyRewards[currentIndex].isReceived;
            dailyRewardComponents.LockImage.SetActive(lockState);
            dailyRewardComponents.RewardClaimed.SetActive(dailyRewards[currentIndex].isReceived);
            dailyRewardComponents.DayText.StringReference.Arguments = new object[] { day };
            dailyRewardComponents.DayText.RefreshString();

            string coinText = (coinRewardValue > 0) ? $"<color=#FFAD00>+{coinRewardValue}</color>" : "";
            string gemText = (gemRewardValue > 0) ? $"<color=#73B5FF>+{gemRewardValue}</color>" : "";

            dailyRewardComponents.RewardText.text = (coinRewardValue > 0 && gemRewardValue > 0)
                ? $"{coinText} {gemText}"
                : $"{coinText}{gemText}";

            dailyRewardComponents.RewardButton.onClick.AddListener(() =>
            {
                if (lockState || dailyRewards[currentIndex].isReceived) return;
                TakeReward(coinRewardValue, gemRewardValue, dailyRewardComponents, currentIndex);
            });
        }
    }

    private void TakeReward(int coinRewardValue, int gemRewardValue, DailyRewardPrefab dailyRewardComponents, int rewardIndex)
    {
        if (dailyRewards[rewardIndex].isReceived) return;

        CoinSystem.Instance.AddCoin(coinRewardValue);
        CoinSystem.Instance.AddGem(gemRewardValue);

        dailyRewards[rewardIndex].isReceived = true;
        lastClaimDateTime = DateTime.UtcNow;

        SaveProgress();

        dailyRewardComponents.RewardClaimed.SetActive(true);
        dailyRewardComponents.RewardButton.interactable = false;

        CloseDailyRewardPanel();
        RewardPanelSystem.Instance.OpenRewardPanel(coinRewardValue, gemRewardValue);
    }

    private void UpdateTimer()
    {
        if (timerText == null || lastClaimDateTime == DateTime.MinValue)
        {
            timerText.text = "";
            return;
        }

        int currentIndex = Mathf.Clamp(CurrentRewardDays - 1, 0, dailyRewards.Length - 1);
        if (!dailyRewards[currentIndex].isReceived)
        {
            timerText.text = "";
            return;
        }

        TimeSpan timeLeft = (lastClaimDateTime + TimeSpan.FromHours(24)) - DateTime.UtcNow;

        if (timeLeft.TotalSeconds <= 0)
        {
            if (!refreshedAfterUnlock)
            {
                refreshedAfterUnlock = true;

                CurrentRewardDays++;

                if (CurrentRewardDays > dailyRewards.Length)
                {
                    ResetRewards();
                }

                SaveProgress();
                RefreshRewardUI();
            }
        }
        else
        {
            timerText.text = string.Format("{0:D2}:{1:D2}:{2:D2}", timeLeft.Hours, timeLeft.Minutes, timeLeft.Seconds);
            refreshedAfterUnlock = false;
        }
    }

    private void RefreshRewardUI()
    {
        foreach (Transform child in dailyRewardParent)
            Destroy(child.gameObject);

        InitializeDailyReward();
    }

    private void ResetRewards()
    {
        foreach (var reward in dailyRewards)
            reward.isReceived = false;

        CurrentRewardDays = 1;
        lastClaimDateTime = DateTime.MinValue;
        SaveProgress();
    }

    private void SaveProgress()
    {
        YG2.saves.currentRewardDays = CurrentRewardDays;
        YG2.saves.lastClaimDateTime = lastClaimDateTime.ToString("o");

        if (YG2.saves.rewardReceived == null || YG2.saves.rewardReceived.Length != dailyRewards.Length)
            YG2.saves.rewardReceived = new int[dailyRewards.Length];

        for (int i = 0; i < dailyRewards.Length; i++)
        {
            YG2.saves.rewardReceived[i] = dailyRewards[i].isReceived ? 1 : 0;
        }

        YG2.SaveProgress();
    }

    private void LoadProgress()
    {
        CurrentRewardDays = YG2.saves.currentRewardDays;
        string lastDateStr = YG2.saves.lastClaimDateTime;

        if (!string.IsNullOrEmpty(lastDateStr))
            DateTime.TryParse(lastDateStr, null, System.Globalization.DateTimeStyles.RoundtripKind, out lastClaimDateTime);

        if (YG2.saves.rewardReceived == null || YG2.saves.rewardReceived.Length != dailyRewards.Length)
            YG2.saves.rewardReceived = new int[dailyRewards.Length];

        for (int i = 0; i < dailyRewards.Length; i++)
        {
            dailyRewards[i].isReceived = YG2.saves.rewardReceived[i] == 1;
        }
    }

    public void OpenDailyRewardPanel()
    {
        if (DailyRewardPanelIsActive) return;

        DailyRewardPanelIsActive = true;

        Image panelImage = dailyRewardPanel.GetComponent<Image>();

        dailyRewardList.transform.localPosition = new Vector3(0f, panelPosY, 0f);
        panelImage.color = new Color(0f, 0f, 0f, 0f);
        dailyRewardPanel.SetActive(true);

        float targetAlpha = panelStartAlpha;
        float targetPanelPosY = 0f;

        panelImage.DOFade(targetAlpha, colorFadeDuration);
        dailyRewardList.transform.DOLocalMoveY(targetPanelPosY, moveDuration);
    }

    public void CloseDailyRewardPanel()
    {
        if (!DailyRewardPanelIsActive) return;

        DailyRewardPanelIsActive = false;
        Image panelImage = dailyRewardPanel.GetComponent<Image>();

        float targetAlpha = 0f;
        float targetPanelPosY = panelPosY;

        panelImage.DOFade(targetAlpha, colorFadeDuration);
        dailyRewardList.transform.DOLocalMoveY(targetPanelPosY, moveDuration).OnComplete(() =>
        {
            dailyRewardPanel.SetActive(false);
        });
    }
}
