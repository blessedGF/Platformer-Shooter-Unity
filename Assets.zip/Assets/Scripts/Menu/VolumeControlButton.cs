using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Audio;

public class VolumeControlButton : MonoBehaviour
{
    [Header("Button Settings")]
    [SerializeField] private Image targetImage;
    [SerializeField] private Sprite[] stateSprites = new Sprite[3];

    [Header("Audio Settings")]
    [SerializeField] private AudioMixer audioMixer;
    [SerializeField] private string volumeParameter = "MasterVolume";

    private int currentState = 0;
    private readonly float[] volumeLevels = { 0f, -10f, -80f };

    private void Start()
    {
        InitializeButton();
    }

    private void InitializeButton()
    {
        if (targetImage == null)
            targetImage = GetComponent<Image>();

        UpdateSystem();
    }

    public void ChangeVolumeState()
    {
        currentState = (currentState + 1) % 3;
        UpdateSystem();
    }

    private void UpdateSystem()
    {
        if (targetImage != null && currentState < stateSprites.Length && stateSprites[currentState] != null)
            targetImage.sprite = stateSprites[currentState];

        if (audioMixer != null)
            audioMixer.SetFloat(volumeParameter, volumeLevels[currentState]);
    }

    private void OnEnable()
    {
        SyncWithCurrentVolume();
    }

    private void SyncWithCurrentVolume()
    {
        if (audioMixer != null)
        {
            if (audioMixer.GetFloat(volumeParameter, out float currentVolume))
            {
                for (int i = 0; i < volumeLevels.Length; i++)
                {
                    if (Mathf.Approximately(currentVolume, volumeLevels[i]))
                    {
                        currentState = i;
                        UpdateSystem();
                        break;
                    }
                }
            }
        }
    }
}