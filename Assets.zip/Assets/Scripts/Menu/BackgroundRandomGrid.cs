using UnityEngine;

public class BackgroundRandomGrid : MonoBehaviour
{
    [SerializeField] private GameObject[] allGrids;
    private void Awake() { Instantiate(allGrids[Random.Range(0, allGrids.Length)]); }
}
