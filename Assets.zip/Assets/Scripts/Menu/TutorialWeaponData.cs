using TMPro;
using UnityEngine;
using UnityEngine.Localization.Components;
using UnityEngine.UI;

public class TutorialWeaponData : MonoBehaviour
{
    [SerializeField] private Button _tutorialWeaponButton;
    [SerializeField] private LocalizeStringEvent _tutorialWeaponNameText;
    public Button TutorialWeaponButton => _tutorialWeaponButton;
    public LocalizeStringEvent TutorialWeaponNameText => _tutorialWeaponNameText;
}
