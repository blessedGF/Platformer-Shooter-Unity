using TMPro;
using UnityEngine;
using UnityEngine.Localization.Components;
using UnityEngine.UI;

public class UpdateSkinInfo : MonoBehaviour
{
    [SerializeField] private Image skinImage;
    [SerializeField] private TextMeshProUGUI skinNameText;
    [SerializeField] private LocalizeStringEvent nameLocalizeStringEvent;
    [SerializeField] private GameObject skinCoinImage;
    [SerializeField] private GameObject skinGemImage;
    [SerializeField] private TextMeshProUGUI skinPriceText;
    [SerializeField] private GameObject lockStateImage;
    [SerializeField] private GameObject purchasedImage;
    [SerializeField] private GameObject freeText;
    [SerializeField] private Button purchaseButton;
    public SkinData SkinData { get; private set; }

    public delegate void UpdateCharacterSkinInfo();
    public UpdateCharacterSkinInfo OnUpdateCharacterSkinInfo { get; private set; }

    public delegate void SetCharacterSkinData(SkinData _skinData);
    public SetCharacterSkinData OnSetCharacterSkinData { get; private set; }

    private void OnEnable()
    {
        OnSetCharacterSkinData = SetSkinData;

        ShopSystem.Instance.OnPurchase += UpdateInfo;
    }
    private void OnDisable()
    {
        ShopSystem.Instance.OnPurchase -= UpdateInfo;
    }
    private void SetSkinData(SkinData _skinData)
    {
        SkinData = _skinData;

        UpdateInfo();
    }
    private void UpdateInfo()
    {
        skinImage.sprite = SkinData.skinImage;

        bool itemIsFree = SkinData.coinPriceValue <= 0 && SkinData.gemPriceValue <= 0;

        skinCoinImage.SetActive(SkinData.coinPriceValue > 0);
        skinGemImage.SetActive(SkinData.gemPriceValue > 0);

        string coinText = (SkinData.coinPriceValue > 0) ? $"<color=#FFAD00>{SkinData.coinPriceValue}</color>" : "";
        string gemText = (SkinData.gemPriceValue > 0) ? $"<color=#73B5FF>{SkinData.gemPriceValue}</color>" : "";

        skinPriceText.text = (SkinData.coinPriceValue > 0 && SkinData.gemPriceValue > 0)
        ? $"{coinText} {gemText}"
        : $"{coinText}{gemText}";

        freeText.SetActive(itemIsFree);

        nameLocalizeStringEvent.StringReference = SkinData.nameLocalizationKey;
        nameLocalizeStringEvent.RefreshString();

        skinNameText.color = SkinData.nameColor;

        lockStateImage.SetActive(SkinData.isLocked);
        purchasedImage.SetActive(!SkinData.isLocked);

        purchaseButton.onClick.AddListener(() =>
        {
            if (SkinData.isLocked)
            {
                PurchaseConfirmPanel.Instance.OpenConfirmPanel(SkinData);
            }
            else
            {
                Debug.Log("Skin is purchased!");
            }
        });
    }
}
