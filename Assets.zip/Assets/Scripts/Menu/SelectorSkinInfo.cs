using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class SelectorSkinInfo : MonoBehaviour
{
    [SerializeField] private Button skinButton;
    [SerializeField] private Image skinImage;
    [SerializeField] private GameObject skinLockImage;

    [NonSerialized] public int _skinNumber;
    [NonSerialized] public SkinData _skinData;
    public int SkinNumber => _skinNumber;
    public SkinData SkinData => _skinData;

    public void Start()
    {
        skinImage.sprite = SkinData.skinImage;
        skinLockImage.SetActive(SkinData.isLocked);
    }
}
