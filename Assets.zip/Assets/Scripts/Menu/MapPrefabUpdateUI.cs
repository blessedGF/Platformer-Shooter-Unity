using System;
using TMPro;
using UnityEngine;
using UnityEngine.Localization.Components;
using UnityEngine.UI;

public class MapPrefabUpdateUI : MonoBehaviour
{
    [SerializeField] private LocalizeStringEvent nameLocalizationKey;
    [SerializeField] private LocalizeStringEvent difficultyLocalizationKey;
    [SerializeField] private Button mapSelectButton;
    [SerializeField] private GameObject mapLockImage;
    [SerializeField] private GameObject rewardPanel;
    [SerializeField] private GameObject coinRewardCount;
    [SerializeField] private GameObject gemRewardCount;
    [SerializeField] private TextMeshProUGUI rewardText;

    [NonSerialized] public Map _map;
    [NonSerialized] public UpdateMapPanel _mapPanel;
    public Map Map => _map;
    public UpdateMapPanel MapPanel => _mapPanel;

    private void Start()
    {
        bool mapIsLocked = Map.lockState;

        nameLocalizationKey.StringReference = Map.nameLocalizationKey;
        difficultyLocalizationKey.StringReference = Map.difficultyLocalizationKey;

        mapLockImage.SetActive(mapIsLocked);
        rewardPanel.SetActive(!mapIsLocked);

        int coinRewardValue = Map.coinRewardCoint;
        int gemRewardValue = Map.gemRewardCoint;

        coinRewardCount.SetActive(coinRewardValue > 0);
        gemRewardCount.SetActive(gemRewardValue > 0);

        string coinText = (coinRewardValue > 0) ? $"<color=#FFAD00>+{coinRewardValue}</color>" : "";
        string gemText = (gemRewardValue > 0) ? $"<color=#73B5FF>+{gemRewardValue}</color>" : "";

        rewardText.text = (coinRewardValue > 0 && gemRewardValue > 0)
        ? $"{coinText} {gemText}"
        : $"{coinText}{gemText}";

        mapSelectButton.interactable = !mapIsLocked;

        mapSelectButton.onClick.AddListener(() => 
        {
            if (mapIsLocked) { return; }

            MapPanel.UpdateMapPanelInfo(Map); 
        });
    }
}
