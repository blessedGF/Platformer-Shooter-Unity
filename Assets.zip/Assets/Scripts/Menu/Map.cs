using UnityEngine;
using UnityEngine.Localization;

[CreateAssetMenu()]
public class Map : ScriptableObject
{
    public int levelNumber;
    public int sceneNumber;
    public LocalizedString nameLocalizationKey;
    public LocalizedString difficultyLocalizationKey;
    public bool lockState;
    public bool isSoloLevel;
    public int coinRewardCoint;
    public int gemRewardCoint;
}
