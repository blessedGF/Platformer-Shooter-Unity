using System.Collections;
using TMPro;
using UnityEngine;

public class UpdateCoinCount : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI coinValueText;
    [SerializeField] private TextMeshProUGUI gemValueText;

    private void OnEnable()
    {
        StartCoroutine(CheckCoinSystemInstance());
    }

    private void OnDisable() 
    {
        CoinSystem.Instance.OnCoinValueUpdate -= UpdateCoinText;
        CoinSystem.Instance.OnGemValueUpdate -= UpdateGemText;
    }

    private void UpdateCoinText(int newCoinValue) => coinValueText.text = $"<color=#FFAD00>{newCoinValue}</color>";
    private void UpdateGemText(int newGemValue) => gemValueText.text = $"<color=#73B5FF>{newGemValue}</color>";

    private IEnumerator CheckCoinSystemInstance()
    {
        while(CoinSystem.Instance == null) 
        {
            yield return null;
        }

        CoinSystem.Instance.OnCoinValueUpdate += UpdateCoinText;
        CoinSystem.Instance.OnGemValueUpdate += UpdateGemText;

        UpdateCoinText(CoinSystem.Instance.CurrentCoinValue);
        UpdateGemText(CoinSystem.Instance.CurrentGemValue);
    }
}
