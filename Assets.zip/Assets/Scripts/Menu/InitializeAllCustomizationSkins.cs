using System.Collections.Generic;
using UnityEngine;

public class InitializeAllCustomizationSkins : MonoBehaviour
{
    [SerializeField] private List<SkinData> skinDatas = new List<SkinData>();
    [SerializeField] private Transform skinsContentList;

    [SerializeField] private GameObject customizationSkinPrefab;
    private void Start()
    {
        CreateAllCustomizationSkins();
    }
    private void CreateAllCustomizationSkins() 
    {
        foreach (var skinData in skinDatas)
        {
            GameObject newCustomizationPrefab = Instantiate(customizationSkinPrefab, skinsContentList);
            UpdateSkinInfo skinInfo = newCustomizationPrefab.GetComponent<UpdateSkinInfo>();
            skinInfo.OnSetCharacterSkinData?.Invoke(skinData);
        }
    }
}
