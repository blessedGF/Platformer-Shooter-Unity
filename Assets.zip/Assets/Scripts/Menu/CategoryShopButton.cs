using System.Collections;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class CategoryShopButton : MonoBehaviour, IBeginDragHandler
{
    [Header("References")]
    [SerializeField] private ScrollRect scrollRect;

    [Header("Settings")]
    [SerializeField] private float scrollDuration = 0.5f;
    [SerializeField] private AnimationCurve scrollCurve = AnimationCurve.EaseInOut(0, 0, 1, 1);
    [SerializeField] private bool stopOnUserInteraction = true;

    private Coroutine scrollCoroutine;
    private bool isScrolling;

    private void Start()
    {
        if (scrollRect == null)
        {
            scrollRect = GetComponent<ScrollRect>();
        }
    }

    public void ScrollToNormalizedPosition(float targetNormalizedPos)
    {
        if (scrollRect == null) return;

        targetNormalizedPos = Mathf.Clamp01(targetNormalizedPos);

        // ��������� ������� ���������
        StopCurrentScroll();

        // ��������� ����� ��������
        scrollCoroutine = StartCoroutine(ScrollCoroutine(
            scrollRect.vertical ? targetNormalizedPos : scrollRect.verticalNormalizedPosition,
            scrollRect.horizontal ? targetNormalizedPos : scrollRect.horizontalNormalizedPosition
        ));
    }

    public void ScrollToElement(RectTransform targetElement)
    {
        if (scrollRect == null || targetElement == null) return;

        Canvas.ForceUpdateCanvases();

        // ��������� ��������������� ������� ��������
        Vector2 normalizedPosition = CalculateNormalizedPosition(targetElement);

        ScrollToNormalizedPosition(scrollRect.vertical ? normalizedPosition.y : normalizedPosition.x);
    }

    public void StopCurrentScroll()
    {
        if (scrollCoroutine != null)
        {
            StopCoroutine(scrollCoroutine);
            scrollCoroutine = null;
        }
        isScrolling = false;
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        // ��������� �������� ��� ������ ��������������
        if (stopOnUserInteraction && isScrolling)
        {
            StopCurrentScroll();
        }
    }

    private Vector2 CalculateNormalizedPosition(RectTransform target)
    {
        RectTransform content = scrollRect.content;
        RectTransform viewport = scrollRect.viewport ?? (RectTransform)scrollRect.transform;

        Bounds contentBounds = RectTransformUtility.CalculateRelativeRectTransformBounds(content);
        Bounds targetBounds = RectTransformUtility.CalculateRelativeRectTransformBounds(content, target);
        Bounds viewportBounds = RectTransformUtility.CalculateRelativeRectTransformBounds(viewport);

        Vector2 normalizedPosition = new Vector2(
            scrollRect.horizontal ? CalculateHorizontalOffset(contentBounds, targetBounds, viewportBounds) : scrollRect.horizontalNormalizedPosition,
            scrollRect.vertical ? CalculateVerticalOffset(contentBounds, targetBounds, viewportBounds) : scrollRect.verticalNormalizedPosition
        );

        return normalizedPosition;
    }

    private float CalculateHorizontalOffset(Bounds content, Bounds target, Bounds viewport)
    {
        float contentWidth = content.size.x;
        float viewportWidth = viewport.size.x;

        if (contentWidth <= viewportWidth) return 0.5f;

        float contentMin = content.center.x - content.extents.x;
        float targetPosition = target.center.x - target.extents.x;

        float elementOffset = targetPosition - contentMin;
        float scrollableArea = content.size.x - viewportWidth;

        return Mathf.Clamp01(elementOffset / scrollableArea);
    }

    private float CalculateVerticalOffset(Bounds content, Bounds target, Bounds viewport)
    {
        float contentHeight = content.size.y;
        float viewportHeight = viewport.size.y;

        if (contentHeight <= viewportHeight) return 1f;

        float contentMin = content.center.y - content.extents.y;
        float targetPosition = target.center.y - target.extents.y;

        float elementOffset = targetPosition - contentMin;
        float scrollableArea = content.size.y - viewportHeight;

        return Mathf.Clamp01(1 - (elementOffset / scrollableArea));
    }

    private IEnumerator ScrollCoroutine(float targetVerticalPos, float targetHorizontalPos)
    {
        isScrolling = true;

        Vector2 startPos = new Vector2(
            scrollRect.horizontalNormalizedPosition,
            scrollRect.verticalNormalizedPosition
        );

        Vector2 targetPos = new Vector2(
            targetHorizontalPos,
            targetVerticalPos
        );

        float elapsedTime = 0f;

        while (elapsedTime < scrollDuration)
        {
            if (!isScrolling) yield break;

            elapsedTime += Time.unscaledDeltaTime;
            float t = scrollCurve.Evaluate(elapsedTime / scrollDuration);

            scrollRect.horizontalNormalizedPosition = Mathf.Lerp(startPos.x, targetPos.x, t);
            scrollRect.verticalNormalizedPosition = Mathf.Lerp(startPos.y, targetPos.y, t);

            yield return null;
        }

        scrollRect.horizontalNormalizedPosition = targetPos.x;
        scrollRect.verticalNormalizedPosition = targetPos.y;

        isScrolling = false;
        scrollCoroutine = null;
    }
}
