using System.Collections;
using UnityEngine;
using UnityEngine.Localization.Settings;
using YG;

public class LocaleSelector : MonoBehaviour
{
    private bool isActive;
    private bool currentLocaleRussian = true;

    private void Start()
    {
        if (YG2.lang != "ru")
        {
            ChangeLocale();
        }
    }
    public void ChangeLocale() 
    {
        if (isActive) { return; }

        currentLocaleRussian = !currentLocaleRussian;
        int newLocaleID = currentLocaleRussian ? 1 : 0;
        string newLanguage = currentLocaleRussian ? "ru" : "en";

        StartCoroutine(SetLocale(newLocaleID, newLanguage));
    }
    private IEnumerator SetLocale(int localeID, string language)
    {
        isActive = true;

        yield return LocalizationSettings.InitializationOperation;
        LocalizationSettings.SelectedLocale = LocalizationSettings.AvailableLocales.Locales[localeID];

        YG2.SwitchLanguage(language);

        Debug.Log($"New LocalID = {localeID}");
        Debug.Log($"New Language = {language}");

        isActive = false;
    }
}
