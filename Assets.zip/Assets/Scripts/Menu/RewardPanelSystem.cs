using TMPro;
using UnityEngine;

public class RewardPanelSystem : MonoBehaviour
{
    [SerializeField] private GameObject rewardPanel;
    [SerializeField] private GameObject coinImage;
    [SerializeField] private GameObject gemImage;
    [SerializeField] private TextMeshProUGUI rewardCount;
    public static RewardPanelSystem Instance { get; private set; }
    private void Awake()
    {
        if (Instance == null) { Instance = this; }
    }
    public void OpenRewardPanel(int coinCount, int gemCount)
    {
        rewardPanel.SetActive(true);
        coinImage.SetActive(coinCount > 0);
        gemImage.SetActive(gemCount > 0);

        string coinText = (coinCount > 0) ? $"<color=#FFAD00>+{coinCount}</color>" : "";
        string gemText = (gemCount > 0) ? $"<color=#73B5FF>+{gemCount}</color>" : "";

        rewardCount.text = (coinCount > 0 && gemCount > 0)
        ? $"{coinText} {gemText}"
        : $"{coinText}{gemText}";
    }
    public void CloseRewardPanel()
    {
        rewardPanel.SetActive(false);
        coinImage.SetActive(false);
        gemImage.SetActive(false);

        rewardCount.text = null;
    }
}
