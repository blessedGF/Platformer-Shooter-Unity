using UnityEngine;
using UnityEngine.Localization.Components;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using YG;

public class UpdateMapPanel : MonoBehaviour
{
    [SerializeField] private LocalizeStringEvent localizeStringEvent;
    [SerializeField] private Button mapStartButton;

    private SkinData[] allSkins;
    public Map CurrentSelectedMap { get; private set; }

    private void Awake()
    {
        allSkins = Resources.LoadAll<SkinData>("Skins");
    }
    public void UpdateMapPanelInfo(Map map)
    {
        if (map.lockState) { return; }

        CurrentSelectedMap = map;

        localizeStringEvent.StringReference = map.nameLocalizationKey;

        mapStartButton.onClick.RemoveAllListeners();

        mapStartButton.onClick.AddListener(() =>
        {
            StartGame(map.sceneNumber, map.isSoloLevel);
        });
    }
    public void StartGame(int sceneNumber, bool isSoloLevel)
    {
        bool isReady = isSoloLevel ? 
            CharacterSkinData.Instance.FirstCharacterSkin != null : 
            CharacterSkinData.Instance.FirstCharacterSkin != null && CharacterSkinData.Instance.SecondCharacterSkin != null;

        if (!isReady) { return; }

        if (isSoloLevel)
        {
            int randomSkinNumber = Random.Range(0, allSkins.Length);
            CharacterSkinData.Instance.SecondCharacterSkin = allSkins[randomSkinNumber];
        }

        YG2.InterstitialAdvShow();

        FadeScreenEffect.Instance.StartFadeEffect(1f, 1f, () =>
        {
            SceneManager.LoadScene(sceneNumber);
        });
    }
}
