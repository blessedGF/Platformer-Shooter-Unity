using TMPro;
using UnityEngine;
using UnityEngine.Localization.Components;
using UnityEngine.UI;

public class DailyRewardPrefab : MonoBehaviour
{
    [SerializeField] private LocalizeStringEvent _dayText;
    [SerializeField] private GameObject _coinImage;
    [SerializeField] private GameObject _gemImage;
    [SerializeField] private TextMeshProUGUI _rewardText;
    [SerializeField] private GameObject _lockImage;
    [SerializeField] private GameObject _rewardClaimed;
    [SerializeField] private Button _rewardButton;
    public LocalizeStringEvent DayText => _dayText;
    public GameObject CoinImage => _coinImage;
    public GameObject GemImage => _gemImage;
    public TextMeshProUGUI RewardText => _rewardText;
    public GameObject LockImage => _lockImage;
    public GameObject RewardClaimed => _rewardClaimed;
    public Button RewardButton => _rewardButton;
}
