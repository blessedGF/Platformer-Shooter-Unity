using TMPro;
using UnityEngine;
using UnityEngine.Localization.Components;
using UnityEngine.UI;

public class TutorialWeaponUpdateInfo : MonoBehaviour
{
    [SerializeField] private LocalizeStringEvent tutorialWeaponNameText;
    [SerializeField] private LocalizeStringEvent tutorialWeaponInfoText;
    [SerializeField] private TextMeshProUGUI damageText;
    [SerializeField] private Image tutorialWeaponImage;
    public float WeaponDamageLocale { get; private set; }
    public float WeaponRecoilLocale { get; private set; }
    public float WeaponFiringRateLocale { get; private set; }
    public float WeaponBulletSpeedLocale { get; private set; }
    public int WeaponMaxAmmoLocale { get; private set; }
    public static TutorialWeaponUpdateInfo Instance { get; private set; }

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
    }
    public void UpdateInfo(WeaponData weaponData)
    {
        WeaponDamageLocale = weaponData.damage;
        WeaponRecoilLocale = weaponData.weaponPlayerRecoil;
        WeaponFiringRateLocale = weaponData.firingRate;
        WeaponBulletSpeedLocale = weaponData.bulletSpeed;
        WeaponMaxAmmoLocale = weaponData.maxAmmo;

        tutorialWeaponInfoText.RefreshString();

        tutorialWeaponNameText.StringReference = weaponData.localeWeaponName;
        tutorialWeaponImage.sprite = weaponData.weaponImage;

        if (weaponData.weaponImage != null)
        {
            RectTransform imageRect = tutorialWeaponImage.GetComponent<RectTransform>();

            imageRect.localScale = Vector3.one * weaponData.weaponImageSize;
            imageRect.sizeDelta = new Vector2(
                weaponData.weaponImage.texture.width,
                weaponData.weaponImage.texture.height
            );
            tutorialWeaponImage.preserveAspect = true;
        }
    }
}