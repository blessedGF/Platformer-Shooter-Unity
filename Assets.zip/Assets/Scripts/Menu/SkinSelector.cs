using DG.Tweening;
using System.Collections;
using UnityEngine;
using UnityEngine.Localization.Components;
using UnityEngine.UI;

public class SkinSelector : MonoBehaviour
{
    [SerializeField] private SkinData[] skins;
    [SerializeField] private RectTransform selectorTransform;
    [SerializeField] private GameObject skinPrefab;
    [SerializeField] private Transform skinContentList;
    [SerializeField] private float changeSkinSpeed = 1f;
    [SerializeField] private LocalizeStringEvent skinNameText;
    [SerializeField] private InitializeMaps initializeMaps;

    private Vector3 selectorStartPosX;
    private const float stepValue = 251.28f;

    private GameObject[] skinPrefabs;
    private Coroutine moveCoroutine;
    public int CurrentSkinNumber { get; private set; }

    private void OnEnable()
    {
        CharacterSkinData.Instance.ResetSkins();

        selectorStartPosX = selectorTransform.localPosition;
        InitializeAllSkinsInSelector();
    }
    private void OnDisable()
    {
        selectorTransform.localPosition = selectorStartPosX;
        DestroyAllSkinsInSelector();
    }

    private void InitializeAllSkinsInSelector()
    {
        skinPrefabs = new GameObject[skins.Length];

        for (int i = 0; i < skins.Length; i++)
        {
            int skinIndex = i; 
            GameObject newSkinObject = Instantiate(skinPrefab, skinContentList);
            Button skinButton = newSkinObject.GetComponent<Button>();

            skinButton.onClick.AddListener(() =>
            {
                ChangeSkinNumber(skinIndex);

                if (initializeMaps.IsSoloLevels)
                {
                    if (!skins[CurrentSkinNumber].isLocked)
                    {
                        ChangeSkinNumber(skinIndex);
                        CharacterSkinData.Instance.FirstCharacterSkin = skins[CurrentSkinNumber];
                        skinNameText.StringReference = skins[CurrentSkinNumber].nameLocalizationKey;
                        skinNameText.StringReference.RefreshString();
                    }
                }
            });

            skinPrefabs[i] = newSkinObject;

            SelectorSkinInfo skinInfo = newSkinObject.GetComponent<SelectorSkinInfo>();
            skinInfo._skinData = skins[skinIndex];
            skinInfo._skinNumber = skinIndex;
        }
    }
    private void DestroyAllSkinsInSelector() 
    {
        CurrentSkinNumber = 0;

        foreach (var skin in skinPrefabs)
        {
            Destroy(skin);
        }

        skinPrefabs = null;
    }

    public void ChangeSkinNumber(int value)
    {
        CurrentSkinNumber = value;

        if (moveCoroutine != null) { StopCoroutine(moveCoroutine); }

        moveCoroutine = StartCoroutine(MoveSelector());

        SmoothScaleChange(value);
    }
    private void SmoothScaleChange(int value) 
    {
        for (int i = 0; i < skinPrefabs.Length; i++)
        {
            float targetScale = i == value ? 1f : 0.75f;

            skinPrefabs[i].transform.DOScale(targetScale, 0.5f);
        }
    }
    private IEnumerator MoveSelector() 
    {
        if (selectorTransform != null)
        {
            float skinNumber = Mathf.Clamp(CurrentSkinNumber - 1, 0, skins.Length - 3);

            Vector3 newPos = new Vector3(
                selectorStartPosX.x - stepValue * skinNumber,
                selectorStartPosX.y,
                selectorStartPosX.z
            );

            while (selectorTransform.localPosition != newPos)
            {
                selectorTransform.localPosition = Vector3.Lerp(selectorTransform.localPosition, newPos, Time.deltaTime * changeSkinSpeed);
                yield return null;
            }
        }
    }
    public void SelectFirstCharacterSkin(GameObject button)
    {
        if (!skins[CurrentSkinNumber].isLocked)
        {
            LocalizeStringEvent skinNameButton = button.GetComponent<LocalizeStringEvent>();

            if (skinNameButton != null)
            {
                skinNameButton.StringReference = skins[CurrentSkinNumber].nameLocalizationKey;
                skinNameButton.StringReference.RefreshString();
            }

            CharacterSkinData.Instance.FirstCharacterSkin = skins[CurrentSkinNumber];
        }
    }
    public void SelectSecondCharacterSkin(GameObject button)
    {
        if (!skins[CurrentSkinNumber].isLocked)
        {
            LocalizeStringEvent skinNameButton = button.GetComponent<LocalizeStringEvent>();

            if (skinNameButton != null)
            {
                skinNameButton.StringReference = skins[CurrentSkinNumber].nameLocalizationKey;
                skinNameButton.StringReference.RefreshString();
            }

            CharacterSkinData.Instance.SecondCharacterSkin = skins[CurrentSkinNumber];
        }
    }
}