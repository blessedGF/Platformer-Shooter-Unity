using UnityEngine;
using UnityEngine.Localization;

[CreateAssetMenu()]
public class SkinData : ScriptableObject
{
    public string uniqueId;
    public int skinID;
    public Sprite skinImage;
    public RuntimeAnimatorController skinAnimatorController;
    public int coinPriceValue;
    public int gemPriceValue;
    public LocalizedString nameLocalizationKey;
    public Color nameColor;
    public bool isLocked;
    public bool unlockedByDefault;
}
