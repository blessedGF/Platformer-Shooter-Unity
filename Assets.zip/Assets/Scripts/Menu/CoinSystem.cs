using System;
using UnityEngine;
using UnityEngine.SceneManagement;
using YG;

public class CoinSystem : MonoBehaviour
{
    public int CurrentCoinValue { get; private set; }
    public int CurrentGemValue { get; private set; }
    public static CoinSystem Instance { get; private set; }

    private const int maxCoinValue = 999999;

    public event Action<int> OnCoinValueUpdate;
    public event Action<int> OnGemValueUpdate;

    private void Awake()
    {
        if (Instance == null)
        { 
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else 
        {
            Destroy(gameObject);
        }

        LoadProgress();
    }
    private void OnEnable()
    {
        SceneManager.sceneLoaded += OnSceneLoaded;
    }
    private void OnDisable()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }
    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        InitializeAfterLoad();
    }
    private void InitializeAfterLoad()
    {
        LoadProgress();
    }
    public void AddCoin(int value)
    {
        YG2.saves.coins += value;
        YG2.SaveProgress();

        CurrentCoinValue += value;
        CurrentCoinValue = Mathf.Clamp(CurrentCoinValue, 0, maxCoinValue);

        OnCoinValueUpdate?.Invoke(CurrentCoinValue);

        SaveProgress();

        Debug.Log($"Current coin count: {CurrentCoinValue}");
    }
    public void RemoveCoin(int value)
    {
        YG2.saves.coins -= value;

        CurrentCoinValue -= value;
        CurrentCoinValue = Mathf.Clamp(CurrentCoinValue, 0, maxCoinValue);

        OnCoinValueUpdate?.Invoke(CurrentCoinValue);

        SaveProgress();

        Debug.Log($"Current coin count: {CurrentCoinValue}");
    }
    public void AddGem(int value)
    {
        YG2.saves.gems += value;

        CurrentGemValue += value;
        CurrentGemValue = Mathf.Clamp(CurrentGemValue, 0, maxCoinValue);

        OnGemValueUpdate?.Invoke(CurrentGemValue);

        SaveProgress();

        Debug.Log($"Current gem count: {CurrentGemValue}");
    }
    public void RemoveGem(int value)
    {
        CurrentGemValue -= value;
        CurrentGemValue = Mathf.Clamp(CurrentGemValue, 0, maxCoinValue);

        OnGemValueUpdate?.Invoke(CurrentGemValue);

        SaveProgress();

        Debug.Log($"Current gem count: {CurrentGemValue}");
    }
    private void SaveProgress()
    {
        YG2.saves.coins = CurrentCoinValue;
        YG2.saves.gems = CurrentGemValue;

        YG2.SaveProgress();
    }
    private void LoadProgress()
    {
        CurrentCoinValue = YG2.saves.coins;
        CurrentGemValue = YG2.saves.gems;
    }
}
