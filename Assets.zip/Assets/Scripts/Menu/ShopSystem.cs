using System;
using System.Collections.Generic;
using UnityEngine;
using YG;

public class ShopSystem : MonoBehaviour
{
    public static ShopSystem Instance { get; private set; }

    public event Action OnPurchase;

    private void Awake()
    {
        if (Instance == null) { Instance = this; }

        InitializeSaves();
        LoadAllProgress();
    }

    private void InitializeSaves()
    {
        if (YG2.saves.purchasedWeaponIds == null)
            YG2.saves.purchasedWeaponIds = new List<string>();

        if (YG2.saves.purchasedSkinIds == null)
            YG2.saves.purchasedSkinIds = new List<string>();

        UnlockDefaultItems();
    }

    private void UnlockDefaultItems()
    {
        WeaponData[] allWeapons = Resources.LoadAll<WeaponData>("Weapons");
        foreach (WeaponData weapon in allWeapons)
        {
            if (weapon.unlockedByDefault && !YG2.saves.purchasedWeaponIds.Contains(weapon.uniqueId))
            {
                YG2.saves.purchasedWeaponIds.Add(weapon.uniqueId);
            }
        }

        SkinData[] allSkins = Resources.LoadAll<SkinData>("Skins");
        foreach (SkinData skin in allSkins)
        {
            if (skin.unlockedByDefault && !YG2.saves.purchasedSkinIds.Contains(skin.uniqueId))
            {
                YG2.saves.purchasedSkinIds.Add(skin.uniqueId);
            }
        }
    }

    public void UnlockItem(SkinData skin)
    {
        if (skin == null || !skin.isLocked) return;

        skin.isLocked = false;

        if (!YG2.saves.purchasedSkinIds.Contains(skin.uniqueId))
        {
            YG2.saves.purchasedSkinIds.Add(skin.uniqueId);
            SaveProgress();
        }

#if UNITY_EDITOR
        UnityEditor.EditorUtility.SetDirty(skin);
#endif
    }

    public bool PurchaseItem(SkinData skin)
    {
        if (skin == null || !skin.isLocked || skin.unlockedByDefault) return false;

        if (CoinSystem.Instance.CurrentCoinValue >= skin.coinPriceValue &&
            CoinSystem.Instance.CurrentGemValue >= skin.gemPriceValue)
        {
            CoinSystem.Instance.RemoveCoin(skin.coinPriceValue);
            CoinSystem.Instance.RemoveGem(skin.gemPriceValue);

            UnlockItem(skin);

            OnPurchase?.Invoke();
            return true;
        }

        return false;
    }

    public void UnlockItem(WeaponData weapon)
    {
        if (weapon == null || !weapon.isLocked) return;

        weapon.isLocked = false;

        if (!YG2.saves.purchasedWeaponIds.Contains(weapon.uniqueId))
        {
            YG2.saves.purchasedWeaponIds.Add(weapon.uniqueId);
            SaveProgress();
        }

#if UNITY_EDITOR
        UnityEditor.EditorUtility.SetDirty(weapon);
#endif
    }

    public bool PurchaseItem(WeaponData weapon)
    {
        if (weapon == null || !weapon.isLocked || weapon.unlockedByDefault) return false;

        if (CoinSystem.Instance.CurrentCoinValue >= weapon.coinPriceValue &&
            CoinSystem.Instance.CurrentGemValue >= weapon.gemPriceValue)
        {
            CoinSystem.Instance.RemoveCoin(weapon.coinPriceValue);
            CoinSystem.Instance.RemoveGem(weapon.gemPriceValue);

            UnlockItem(weapon);

            OnPurchase?.Invoke();
            return true;
        }

        return false;
    }

    private void SaveProgress()
    {
        YG2.SaveProgress();

#if UNITY_EDITOR
        UnityEditor.AssetDatabase.SaveAssets();
#endif
    }

    private void LoadAllProgress()
    {
        LoadSavesSkins();
        LoadSavesWeapon();
    }

    private void LoadSavesWeapon()
    {
        WeaponData[] allWeapons = Resources.LoadAll<WeaponData>("Weapons");

        foreach (WeaponData weapon in allWeapons)
        {
            if (weapon.unlockedByDefault)
            {
                weapon.isLocked = false;
            }
            else
            {
                weapon.isLocked = true;
            }

            if (YG2.saves.purchasedWeaponIds.Contains(weapon.uniqueId))
            {
                weapon.isLocked = false;
            }

#if UNITY_EDITOR
            UnityEditor.EditorUtility.SetDirty(weapon);
#endif
        }

#if UNITY_EDITOR
        UnityEditor.AssetDatabase.SaveAssets();
#endif
    }

    private void LoadSavesSkins()
    {
        SkinData[] allSkins = Resources.LoadAll<SkinData>("Skins");

        foreach (SkinData skin in allSkins)
        {
            if (skin.unlockedByDefault)
            {
                skin.isLocked = false;
            }
            else
            {
                skin.isLocked = true;
            }

            if (YG2.saves.purchasedSkinIds.Contains(skin.uniqueId))
            {
                skin.isLocked = false;
            }

#if UNITY_EDITOR
            UnityEditor.EditorUtility.SetDirty(skin);
#endif
        }

#if UNITY_EDITOR
        UnityEditor.AssetDatabase.SaveAssets();
#endif
    }
}