using System.Collections.Generic;
using UnityEngine;

public class InitializeAllShopWeapon : MonoBehaviour
{
    [SerializeField] private List<WeaponData> weaponDatas = new List<WeaponData>();
    [SerializeField] private Transform weaponContentList;

    [SerializeField] private GameObject shopWeaponPrefab;
    private void Start()
    {
        CreateAllShopWeapon();
    }
    private void CreateAllShopWeapon()
    {
        foreach (var weaponData in weaponDatas)
        {
            GameObject newShopWeaponPrefab = Instantiate(shopWeaponPrefab, weaponContentList);
            UpdateShopWeaponInfo shopWeaponInfo = newShopWeaponPrefab.GetComponent<UpdateShopWeaponInfo>();
            shopWeaponInfo.OnSetShopWeaponData?.Invoke(weaponData);
        }
    }
}
