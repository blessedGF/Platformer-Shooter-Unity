using UnityEngine;

public class CharacterSkinData : MonoBehaviour
{
    public SkinData FirstCharacterSkin { get; set; }
    public SkinData SecondCharacterSkin { get; set; }

    public static CharacterSkinData Instance;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;

        DontDestroyOnLoad(gameObject);
    }
    public void ResetSkins()
    {
        FirstCharacterSkin = null;
        SecondCharacterSkin = null;
    }
}