using DG.Tweening;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using YG;

public class ResetProgress : MonoBehaviour
{
    [SerializeField] private GameObject resetPanel;
    [SerializeField] private Image resetPanelImage;
    [Header("Animation settings")]
    [SerializeField] private float fadeDuration = 1f;
    [SerializeField] private float moveDuration = 1f;
    [SerializeField] private float panelPosX = -2000f;

    private float startAlpha;
    private bool panelIsOpen;
    private void Awake()
    {
        startAlpha = resetPanelImage.color.a;
    }
    public void OpenAnimationPanel()
    {
        if (panelIsOpen) { return; }

        panelIsOpen = true;

        resetPanel.transform.localPosition = new Vector3(panelPosX, 0f, 0f);
        resetPanelImage.color = new Color(0f, 0f, 0f, 0f);

        resetPanelImage.gameObject.SetActive(true);

        resetPanelImage.DOFade(startAlpha, fadeDuration);
        resetPanel.transform.DOLocalMoveX(0f, moveDuration);
    }
    public void CloseAnimationPanel()
    {
        if (!panelIsOpen) { return; }

        panelIsOpen = false;

        resetPanelImage.DOFade(0f, fadeDuration);
        resetPanel.transform.DOLocalMoveX(panelPosX * -1f, moveDuration).OnComplete(() =>
        {
            resetPanelImage.gameObject.SetActive(false);
        });
    }
    public void ResetAllProgress()
    {
        YG2.SetDefaultSaves();
        YG2.SaveProgress();

        FadeScreenEffect.Instance.StartFadeEffect(1f, 1f, () =>
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        });
    }
}
