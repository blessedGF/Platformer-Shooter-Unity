using System;
using System.Collections.Generic;

namespace YG
{
    public partial class SavesYG
    {
        public int coins = 10;
        public int gems = 5;

        public List<string> purchasedWeaponIds = new List<string>();
        public List<string> purchasedSkinIds = new List<string>();

        public int currentRewardDays = 1;
        public string lastClaimDateTime;
        public int[] rewardReceived = new int[8];
    }
}