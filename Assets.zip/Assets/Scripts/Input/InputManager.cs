using UnityEngine;
using UnityEngine.InputSystem;

public class InputManager : MonoBehaviour
{
    [SerializeField] private InputActionAsset playerControls;

    private InputAction moveAction;
    private InputAction jumpAction;
    private InputAction fireAction;
    public float MoveInput { get; private set; }
    public float JumpInput { get; private set; }
    public float FireInput { get; private set; }

    private PlayerController playerController;

    private void Start()
    {
        playerController = GetComponent<PlayerController>();

        string currentPlayerMap = playerController.IsFirstPlayer ? "FirstPlayer" : "SecondPlayer";

        moveAction = playerControls.FindActionMap(currentPlayerMap).FindAction("Move");
        jumpAction = playerControls.FindActionMap(currentPlayerMap).FindAction("Jump");
        fireAction = playerControls.FindActionMap(currentPlayerMap).FindAction("Fire");

        moveAction.Enable();
        fireAction.Enable();
        jumpAction.Enable();

        RegisterInputAction();
    }
    private void OnDestroy()
    {
        moveAction.Disable();
        jumpAction.Disable();
        fireAction.Disable();
    }
    private void RegisterInputAction() 
    {
        moveAction.performed += context => MoveInput = context.ReadValue<float>();
        moveAction.canceled += context => MoveInput = 0f;

        jumpAction.performed += context => JumpInput = context.ReadValue<float>();
        jumpAction.canceled += context => JumpInput = 0f;

        fireAction.performed += context => FireInput = context.ReadValue<float>();
        fireAction.canceled += context => FireInput = 0f;
    }
}
