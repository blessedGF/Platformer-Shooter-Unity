using System.Collections;
using UnityEngine;

public class CameraZoom : MonoBehaviour
{
    [SerializeField] private float maxZoomValue = 7f;
    [SerializeField] private float minZoomValue = 3f;
    [SerializeField] private float additionalZoomValue = 1f;
    [SerializeField] private float zoomSpeed = 1f;
    [SerializeField] private float minDistance = 10f;
    [SerializeField] private float cameraMoveSpeed = 1f;

    private Camera mainCamera;

    private Vector3 mainCameraStartPos;
    private float mainCameraStartSize;
    private Vector2 smoothCameraPos;

    private float startDistance;

    private GameObject[] targets = new GameObject[2];

    private void Start()
    {
        StartCoroutine(WaitPlayers());

        RoundWinAnimation.Instance.OnAnimationStarted += DisableCameraZoom;
    }
    private void OnDisable()
    {
        RoundWinAnimation.Instance.OnAnimationStarted -= DisableCameraZoom;
    }
    private void DisableCameraZoom() => this.enabled = false;
    private IEnumerator WaitPlayers()
    {
        while (true)
        {
            targets = GameObject.FindGameObjectsWithTag("Player");

            if (targets != null && targets.Length >= 2 && targets[0] != null && targets[1] != null)
                break;

            yield return null;
        }

        mainCamera = GetComponent<Camera>();

        if (mainCamera == null) { yield break; }

        mainCameraStartPos = mainCamera.transform.position;
        mainCameraStartSize = mainCamera.orthographicSize;

        smoothCameraPos = mainCamera.transform.position;

        startDistance = Vector2.Distance(
            targets[0].transform.position,
            targets[1].transform.position
        );
    }
    private void Update()
    {
        if (targets != null && targets.Length >= 2 && targets[0] != null && targets[1] != null) 
        {
            Vector2 firstTargetPosition = targets[0].transform.position;
            Vector2 secondTargetPosition = targets[1].transform.position;

            float distance = Vector2.Distance(firstTargetPosition, secondTargetPosition);

            float targetZoom = distance > minDistance ? mainCameraStartSize : distance / startDistance * mainCameraStartSize + additionalZoomValue;
            targetZoom = Mathf.Clamp(targetZoom, minZoomValue, maxZoomValue);

            Vector2 targetCameraPos = distance > minDistance ? mainCameraStartPos : Vector2.Lerp(firstTargetPosition, secondTargetPosition, 0.5f);
            smoothCameraPos = Vector2.Lerp(smoothCameraPos, targetCameraPos, Time.deltaTime * cameraMoveSpeed);

            mainCamera.orthographicSize = Mathf.Lerp(mainCamera.orthographicSize, targetZoom, Time.deltaTime * zoomSpeed);

            mainCamera.transform.position = new Vector3(smoothCameraPos.x, smoothCameraPos.y, mainCameraStartPos.z);
        }
    }
}
