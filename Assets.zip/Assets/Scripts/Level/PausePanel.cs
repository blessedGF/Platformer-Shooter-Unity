using UnityEngine;
using UnityEngine.SceneManagement;
using YG;

public class PausePanel : MonoBehaviour
{
    [SerializeField] private GameObject pausePanel;
    [SerializeField] private GameObject interfacePanel;

    private bool pausePanelIsOpen;
    public void TogglePausePanel() 
    {
        pausePanelIsOpen = !pausePanelIsOpen;
        pausePanel.SetActive(pausePanelIsOpen);
        interfacePanel.SetActive(!pausePanelIsOpen);

        Time.timeScale = pausePanelIsOpen ? 0f : 1f;
    }
    public void ReturnToMainMenu()
    {
        YG2.InterstitialAdvShow();

        FadeScreenEffect.Instance.StartFadeEffect(1f, 1f, () => 
        {
            Time.timeScale = 1f;
            Time.fixedDeltaTime = Time.fixedDeltaTime * Time.timeScale;

            RoundSystem.Instance.NullifyPlayerScore();
            SceneManager.LoadScene(0);
        });
    }
}
