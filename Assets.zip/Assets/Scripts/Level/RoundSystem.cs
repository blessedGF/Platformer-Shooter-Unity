using System;
using UnityEngine;
using UnityEngine.SceneManagement;

public class RoundSystem : MonoBehaviour
{
    [Header("The value of points to win")]
    [SerializeField] private int maxScore = 5;
    public int FirstPlayerScore { get; private set; }
    public int SecondPlayerScore { get; private set; }
    public bool RoundIsEnding { get; private set; }
    public bool GameIsEnding { get; private set; }

    public event Action<string> OnGameEnding;
    public static RoundSystem Instance { get; private set; }

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }

        SceneManager.activeSceneChanged += SceneInitialization;
    }
    private void Start()
    {
        var currentScene = SceneManager.GetActiveScene();
        SceneInitialization(currentScene, currentScene);
    }
    private void SceneInitialization(Scene current, Scene next)
    {
        RoundIsEnding = false;
    }
    public void AddPlayerScore(int scoreValue, GameObject player)
    {
        if (GameIsEnding || RoundIsEnding) return;
        if (player == null) return;

        if (!player.TryGetComponent(out PlayerController playerController)) return;

        RoundIsEnding = true;

        bool isFirstPlayer = playerController.IsFirstPlayer;
        int newScore = (isFirstPlayer ? FirstPlayerScore : SecondPlayerScore) + scoreValue;
        string playerNumber = isFirstPlayer ? "1" : "2";

        if (isFirstPlayer) { FirstPlayerScore = newScore; }
        else { SecondPlayerScore = newScore; }

        if (newScore >= maxScore)
        {
            OnGameEnding?.Invoke(playerNumber);
            GameIsEnding = true;
        }

        ScoreTextUpdate.Instance.ChangeScoreText?.Invoke();
    }
    public void NullifyPlayerScore() 
    {
        FirstPlayerScore = 0;
        SecondPlayerScore = 0;

        RoundIsEnding = false;
        GameIsEnding = false;
    }
}
