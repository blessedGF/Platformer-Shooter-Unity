using System;
using System.Collections;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.SceneManagement;

public class RoundWinAnimation : MonoBehaviour
{
    [Header("AudioMixer with Pitch effect")]
    [SerializeField] private AudioMixer audioMixer;
    [Space]
    [Header("Parameters")]
    [SerializeField] private float slowEffectMultiplier = 0.5f;
    [SerializeField] private float slowEffectSpeedChange = 1f;
    [SerializeField] private float cameraMoveSpeed = 1f;
    [SerializeField] private float minZoomValue = 3f;
    [SerializeField] private float fadePanelSpeedChange = 1.5f;
    public static RoundWinAnimation Instance { get; private set; }

    private Coroutine currentWinRoundAnimationCoroutine;

    public event Action OnAnimationStarted;

    private const string PITCH_PARAMETRS = "PitchSFX";

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }
    public void PlayerAnimationWinRound(GameObject winningPlayer)
    {
        if (RoundSystem.Instance.GameIsEnding) { return; }

        if (currentWinRoundAnimationCoroutine != null) { return; }

        currentWinRoundAnimationCoroutine = StartCoroutine(AnimationWinningRound(winningPlayer));
    }
    private IEnumerator AnimationWinningRound(GameObject winningPlayer)
    {
        OnAnimationStarted?.Invoke();

        float slowValue = Time.timeScale;

        Camera mainCamera = GameObject.FindGameObjectWithTag("MainCamera").GetComponent<Camera>();

        float startZoomValue = mainCamera.orthographicSize;

        Vector3 cameraStartPos = mainCamera.transform.position;

        while (MathF.Round(slowValue, 2) > slowEffectMultiplier)
        {
            slowValue = Mathf.Lerp(slowValue, slowEffectMultiplier, Time.deltaTime * slowEffectSpeedChange);

            Time.timeScale = slowValue;
            Time.fixedDeltaTime = Time.fixedDeltaTime * Time.timeScale;

            audioMixer.SetFloat(PITCH_PARAMETRS, slowValue);

            if (winningPlayer != null)
            {
                mainCamera.orthographicSize -= Time.deltaTime * slowEffectSpeedChange;
                mainCamera.orthographicSize = Mathf.Clamp(mainCamera.orthographicSize, minZoomValue, startZoomValue);

                Vector3 playerPos = !winningPlayer.IsUnityNull() ? winningPlayer.transform.position : Vector3.zero;
                Vector3 targetCameraPos = new Vector3(playerPos.x, playerPos.y, cameraStartPos.z);

                mainCamera.transform.position = Vector3.MoveTowards(mainCamera.transform.position, targetCameraPos, Time.deltaTime * cameraMoveSpeed);
            }

            yield return null;
        }

        FadeScreenEffect.Instance.StartFadeEffect(1, fadePanelSpeedChange, () =>
        {
            Time.timeScale = 1f;
            Time.fixedDeltaTime = Time.fixedDeltaTime * Time.timeScale;

            audioMixer.SetFloat(PITCH_PARAMETRS, 1);

            currentWinRoundAnimationCoroutine = null;

            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        });
    }
}
