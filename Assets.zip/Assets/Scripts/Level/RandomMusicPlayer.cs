using UnityEngine;
using System.Collections.Generic;

public class RandomMusicPlayer : MonoBehaviour
{
    [SerializeField] private List<AudioClip> musicTracks;

    private AudioSource audioSource;
    private int lastPlayedIndex = -1;
    private void Start()
    {
        audioSource = GetComponent<AudioSource>();

        if (musicTracks == null || musicTracks.Count == 0)
        {
            Debug.LogError("No music tracks assigned in RandomMusicPlayer!");
            return;
        }

        PlayRandomTrack();
    }
    private void PlayRandomTrack()
    {
        int randomIndex;

        do { randomIndex = Random.Range(0, musicTracks.Count); }
        while (musicTracks.Count > 1 && randomIndex == lastPlayedIndex);

        lastPlayedIndex = randomIndex;
        audioSource.clip = musicTracks[randomIndex];
        audioSource.Play();
    }
}