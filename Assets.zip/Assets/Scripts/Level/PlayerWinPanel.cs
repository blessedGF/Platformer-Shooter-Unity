using DG.Tweening;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Localization.Components;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using YG;

public class PlayerWinPanel : MonoBehaviour
{
    [SerializeField] private Map currentMap;
    [SerializeField] private GameObject winningPanel;
    [SerializeField] private GameObject winningInfoPanel;
    [SerializeField] private GameObject interfacePanel;
    [SerializeField] private LocalizeStringEvent winText;
    [Header("Reward info")]
    [SerializeField] private GameObject coinRewardImage;
    [SerializeField] private GameObject gemRewardImage;
    [SerializeField] private TextMeshProUGUI rewardText;
    [Header("Animation settings")]
    [SerializeField] private float colorFadeDuration = 1f;
    [SerializeField] private float moveDuration = 1f;
    [SerializeField] private float panelPosY = 1000f;

    private List<Map> mapList = new List<Map>();
    public bool WinPanelIsActive { get; private set; }
    private float panelStartAlpha;
    private void Awake()
    {
        panelStartAlpha = winningPanel.GetComponent<Image>().color.a;

        bool isSoloLevel = currentMap.isSoloLevel;

        Map[] allMap = Resources.LoadAll<Map>("Maps");

        foreach (var item in allMap)
        {
            if (item.isSoloLevel == isSoloLevel)
            {
                mapList.Add(item);
            }
        }
    }
    private void OnEnable()
    {
        StartCoroutine(RoundSystemInitializationCheck());
    }
    private void OnDisable()
    {
        RoundSystem.Instance.OnGameEnding -= OpenWinningPanel;
    }
    public void OpenWinningPanel(string playerNumber)
    {
        if (CoinSystem.Instance != null)
        {
            CoinSystem.Instance.AddCoin(currentMap.coinRewardCoint);
            CoinSystem.Instance.AddGem(currentMap.gemRewardCoint);
        }

        RewardInfo(currentMap);

        if (WinPanelIsActive) { return; }

        WinPanelIsActive = true;

        Image panelImage = winningPanel.GetComponent<Image>();

        winningInfoPanel.transform.localPosition = new Vector3(0f, panelPosY, 0f);
        panelImage.color = new Color(0f, 0f, 0f, 0f);
        winningPanel.SetActive(true);
        interfacePanel.SetActive(false);

        winText.StringReference.Arguments = new object[] { playerNumber }; 
        winText.RefreshString();

        float targetAlpha = panelStartAlpha;
        float targetPanelPosY = 0f;

        panelImage.DOFade(targetAlpha, colorFadeDuration);

        winningInfoPanel.transform.DOLocalMoveY(targetPanelPosY, moveDuration);
    }
    private void RewardInfo(Map map)
    {
        int coinRewardValue = map.coinRewardCoint;
        int gemRewardValue = map.gemRewardCoint;

        coinRewardImage.SetActive(coinRewardValue > 0);
        gemRewardImage.SetActive(gemRewardValue > 0);

        string coinText = (coinRewardValue > 0) ? $"<color=#FFAD00>+{coinRewardValue}</color>" : "";
        string gemText = (gemRewardValue > 0) ? $"<color=#73B5FF>+{gemRewardValue}</color>" : "";

        rewardText.text = (coinRewardValue > 0 && gemRewardValue > 0)
        ? $"{coinText} {gemText}"
        : $"{coinText}{gemText}";
    }
    public void NextButton()
    {
        int nextSceneIndex = 0;
        int nextLevelNumber = currentMap.levelNumber + 1;
        bool findNextLevel = false;

        foreach (Map map in mapList) 
        { 
            if (map.levelNumber == nextLevelNumber)
            {
                if (!map.lockState)
                {
                    nextSceneIndex = map.sceneNumber;
                    findNextLevel = true;
                    break;
                }
            }
        }

        if (findNextLevel)
        {
            YG2.InterstitialAdvShow();

            FadeScreenEffect.Instance.StartFadeEffect(1f, 1f, () =>
            {
                RoundSystem.Instance.NullifyPlayerScore();
                SceneManager.LoadScene(nextSceneIndex);
            });
        }
    }
    public void RepeatButton()
    {
        YG2.InterstitialAdvShow();

        FadeScreenEffect.Instance.StartFadeEffect(1f, 1f, () =>
        {
            RoundSystem.Instance.NullifyPlayerScore();
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        });
    }
    public void HomeButton() 
    {
        YG2.InterstitialAdvShow();

        FadeScreenEffect.Instance.StartFadeEffect(1f, 1f, () =>
        {
            RoundSystem.Instance.NullifyPlayerScore();
            SceneManager.LoadScene(0);
        });
    }
    private IEnumerator RoundSystemInitializationCheck() 
    { 
        while(RoundSystem.Instance == null) 
        {
            yield return null;
        }

        RoundSystem.Instance.OnGameEnding += OpenWinningPanel;
    }
}
