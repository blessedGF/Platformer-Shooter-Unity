using System.Collections.Generic;
using UnityEngine;

public class InitializeMaps : MonoBehaviour
{
    [SerializeField] private List<Map> mapList = new List<Map>();

    [SerializeField] private GameObject mapPrefab;
    [SerializeField] private Transform mapParent;

    [SerializeField] private UpdateMapPanel updateMapPanel;

    [SerializeField] private bool _isSoloLevels;
    public bool IsSoloLevels => _isSoloLevels;

    private void Awake()
    {
        InitializeAllMap();
    }
    private void InitializeAllMap()
    {
        foreach(var map in mapList) 
        {
            GameObject newMap = Instantiate(mapPrefab, mapParent);

            MapPrefabUpdateUI newMapPrefabUpdateUI = newMap.GetComponent<MapPrefabUpdateUI>();
            newMapPrefabUpdateUI._map = map;
            newMapPrefabUpdateUI._mapPanel = updateMapPanel;
        }
    }
}
