using UnityEngine;

public class PlayerLookDirectional : MonoBehaviour
{
    [SerializeField] PlayerController playerController;

    private SpriteRenderer spriteRenderer;
    public bool LeftDirectional { get; private set; }

    private void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }
    private void Update()
    {
        ChangeDirectional();
    }
    private void ChangeDirectional()
    {
        if (playerController.MoveInput != 0f)
        {
            bool flipX = playerController.MoveInput < 0f;
            spriteRenderer.flipX = flipX;
            LeftDirectional = flipX;
        }
    }
}
