using Pathfinding;
using System.Collections;
using UnityEngine;

public class AIController : PlayerController
{
    [Header("Pathfinding")]
    [SerializeField] private Transform target;
    [SerializeField] private float pathUpdateTime = 0.3f;
    [SerializeField] private float targetUpdateTime = 1f;

    private Seeker seeker;
    private WeaponSystem weaponSystem;
    private Path path;
    private int currentWaypoint = 1;
    private Vector2 direction;

    private bool lockMovement;

    public override void Initialize()
    {
        base.Initialize();

        seeker = GetComponent<Seeker>();
        weaponSystem = GetComponent<WeaponSystem>();

        InvokeRepeating(nameof(UpdatePath), 0f, pathUpdateTime);

        StartCoroutine(SetTarget());
    }
    private void UpdatePath()
    {
        if (seeker.IsDone() && target != null)
        {
            seeker.StartPath(transform.position, target.position, OnPathComplete);
        }
    }

    private void OnPathComplete(Path p)
    {
        if (!p.error)
        {
            path = p;
        }
    }
    public override void Jump()
    {
        if (direction.y > 0f)
        {
            if (IsGrounded && timeToJump >= timeToNextJump)
            {
                timeToJump = 0f;
                rb.velocity = new Vector2(rb.velocity.x, jumpForce);
            }
        }
    }
    public override void InputMove()
    {
        if (path == null) { return; }

        if (currentWaypoint >= path.vectorPath.Count)
        {
            return;
        }

        direction = (path.vectorPath[currentWaypoint] - transform.position).normalized; ;

        MoveInput = inputState.MoveIsLocked || lockMovement ? 0f : 1 * Mathf.Sign(direction.x);
    }
    private Transform FindPlayerTarget()
    {
        GameObject[] players = GameObject.FindGameObjectsWithTag("Player");

        if (players == null)
        {
            return null;
        }

        foreach (var player in players)
        {
            if (player != this.gameObject)
            {
                target = player.transform;

                return player.transform;
            }
        }

        return null;
    }
    private Transform FindWeaponTarget()
    {
        GameObject[] weapons = GameObject.FindGameObjectsWithTag("Weapon");

        if (weapons == null)
        {
            return null;
        }

        GameObject closestWeapon = null;
        float closestDistance = Mathf.Infinity;
        Vector2 playerPosition = transform.position;

        foreach (GameObject weapon in weapons)
        {
            float distance = Vector2.Distance(weapon.transform.position, playerPosition);

            if (distance < closestDistance)
            {
                closestDistance = distance;
                closestWeapon = weapon;
            }
        }

        if (closestWeapon != null)
        {
            return closestWeapon.transform;
        }

        return null;
    }
    private IEnumerator SetTarget()
    {
        if (weaponSystem.weaponData == null || weaponSystem.currentAmmoValue <= 0)
        {
            Transform weaponTarget = FindWeaponTarget();
            target = weaponTarget != null ? weaponTarget : FindPlayerTarget();
        }
        else
        {
            Transform playerTarget = FindPlayerTarget();
            PlayerHealth playerHealth = playerTarget.GetComponent<PlayerHealth>();

            lockMovement = playerHealth?.currentHealth <= 0;
            target = playerTarget;
        }

        yield return new WaitForSeconds(targetUpdateTime);

        StartCoroutine(SetTarget());
    }
}