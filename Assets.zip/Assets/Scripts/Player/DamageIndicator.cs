using System.Collections;
using Unity.VisualScripting;
using UnityEngine;

public class DamageIndicator : MonoBehaviour
{
    [SerializeField] private float colorIndicatorDuration = 0.1f;
    [SerializeField] private SpriteRenderer spriteRenderer;
    [SerializeField] private GameObject hitEffect;

    private Coroutine hitColorCoroutine;

    private IHealth health;
    private void Awake()
    {
        health = GetComponent<IHealth>();
    }

    private void OnEnable()
    {
        health.OnHit += Indicator;
    }
    private void OnDisable()
    {
        health.OnHit -= Indicator;
    }
    private void Indicator(float damageValue)
    {
        GameObject hitPrefab = Instantiate(hitEffect, transform.position, Quaternion.identity);
        HitCountEffect hitEffectComponent = hitPrefab.GetComponent<HitCountEffect>();
        hitEffectComponent._damage = damageValue;

        if (spriteRenderer != null)
        {
            if (hitColorCoroutine != null) { return; }

            hitColorCoroutine = StartCoroutine(HitColorIndicator());
        }
    }
    private IEnumerator HitColorIndicator() 
    {
        spriteRenderer.color = Color.red;

        yield return new WaitForSeconds(colorIndicatorDuration);

        spriteRenderer.color = Color.white;

        hitColorCoroutine = null;
    }
}
