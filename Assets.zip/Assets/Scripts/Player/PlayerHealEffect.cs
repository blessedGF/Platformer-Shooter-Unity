using UnityEngine;

public class PlayerHealEffect : MonoBehaviour
{
    [SerializeField] private GameObject healParticlePrefab;
    [SerializeField] private GameObject healEffect;

    private PlayerHealth playerHealth;

    private void OnEnable()
    {
        playerHealth = GetComponent<PlayerHealth>();

        playerHealth.OnRegen += HealEffect;
    }
    private void OnDisable()
    {
        playerHealth.OnRegen -= HealEffect;
    }
    private void HealEffect(float value)
    {
        GameObject newParticleObject = Instantiate(healParticlePrefab, transform.position, Quaternion.identity);

        ParticleSystem healParticleSystem = newParticleObject.GetComponent<ParticleSystem>();

        if (!healParticleSystem.main.loop)
        {
            float duration = healParticleSystem.main.duration + healParticleSystem.main.startLifetime.constantMax;
            Destroy(newParticleObject, duration);
        }

        GameObject healPrefab = Instantiate(healEffect, transform.position, Quaternion.identity);
        HealCountEffect healEffectComponent = healPrefab.GetComponent<HealCountEffect>();
        healEffectComponent._heal = value;
    }
}
