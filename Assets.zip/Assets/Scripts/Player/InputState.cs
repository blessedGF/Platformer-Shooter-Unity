using System.Collections.Generic;
using UnityEngine;

public class InputState : MonoBehaviour
{
    public Dictionary<string, bool> moveDictionary = new Dictionary<string, bool>();

    private bool moveIsLocked = false;
    public bool MoveIsLocked => moveIsLocked;

    private void UpdateLockState(Dictionary<string, bool> dictionary, out bool lockState)
    {
        lockState = false;

        foreach (var item in dictionary.Values)
        {
            if (item)
            {
                lockState = true;
                break;
            }
        }
    }

    private void UpdateMovementLockState()
    {
        UpdateLockState(moveDictionary, out moveIsLocked);
    }

    public void AddLockMovement(string key)
    {
        moveDictionary[key] = true;
        UpdateMovementLockState();
    }

    public void RemoveLockMovement(string key)
    {
        moveDictionary.Remove(key);
        UpdateMovementLockState();
    }
}
