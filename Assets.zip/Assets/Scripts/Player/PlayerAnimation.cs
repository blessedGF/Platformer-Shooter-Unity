using UnityEngine;

public class PlayerAnimation : MonoBehaviour
{
    [SerializeField] private PlayerController playerController;

    private Animator animator;

    private void Start() => animator = GetComponent<Animator>();

    private void Update()
    {
        animator.SetBool("IsRun", playerController.MoveInput != 0);
        animator.SetBool("IsFalling", !playerController.IsGrounded);
    }
}