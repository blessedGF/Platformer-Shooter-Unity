using UnityEngine;

public class DeathGround : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision != null)
        {
            IHealth health = collision.GetComponent<IHealth>();

            health?.RemoveHealth(Mathf.Infinity, gameObject);
        }
    }
}
