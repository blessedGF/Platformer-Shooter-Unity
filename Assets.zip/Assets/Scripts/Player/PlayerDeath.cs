using UnityEngine;

public class PlayerDeath : MonoBehaviour
{
    [SerializeField] private Animator animator;

    private PlayerHealth playerHealth;
    private Collider2D playerCollider;
    private Rigidbody2D playerRigidbody;
    private InputState inputState;

    private void OnEnable()
    {
        playerHealth = GetComponent<PlayerHealth>();
        playerCollider = GetComponent<Collider2D>();
        playerRigidbody = GetComponent<Rigidbody2D>();
        inputState = GetComponent<InputState>();

        playerHealth.OnDead += Death;
    }
    private void OnDisable()
    {
        playerHealth.OnDead -= Death;
    }
    private void Death(GameObject attacker) 
    {
        IHealth attackerHealth = attacker.GetComponent<IHealth>();

        if (attackerHealth == null || attacker == gameObject) 
        {
            GameObject[] players = GameObject.FindGameObjectsWithTag("Player");

            foreach (var player in players)
            {
                if (player != gameObject) 
                {
                    attacker = player;
                }
            }
        }

        RoundSystem.Instance.AddPlayerScore(1, attacker);
        RoundWinAnimation.Instance.PlayerAnimationWinRound(attacker);

        inputState.AddLockMovement("Death");

        animator.SetTrigger("IsDead");

        playerCollider.enabled = false;
        playerRigidbody.isKinematic = true;
        playerRigidbody.velocity = Vector2.zero;
    }
}
