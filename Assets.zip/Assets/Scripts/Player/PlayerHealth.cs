using System;
using UnityEngine;

public class PlayerHealth : MonoBehaviour, IHealth
{
    [SerializeField] private float setMaxHealth = 100f;
    public float currentHealth { get; set; }
    public float maxHealth { get; set; }
    public bool isDead { get; set; } = false;

    public event Action<GameObject> OnDead;
    public event Action<float> OnHit;

    public event Action<float> OnRegen;

    private void Start()
    {
        maxHealth = setMaxHealth;
        currentHealth = maxHealth;
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("FirstAidKit"))
        {
            AddHealth(maxHealth);

            Destroy(collision.gameObject);
        }
    }
    public void RemoveHealth(float value, GameObject attackingPlayer)
    {
        if (value <= 0) { return; }

        OnHit?.Invoke(value);

        if (currentHealth > 0f)
        {
            if (currentHealth - value > 0f)
            {
                currentHealth -= value;
            }
            else
            {
                Death(attackingPlayer);
            }
        }
    }
    public void AddHealth(float value)
    {
        if (value <= 0) { return; }

        if (currentHealth > 0f)
        {
            if (currentHealth + value < maxHealth)
            {
                currentHealth += value;
            }
            else
            {
                currentHealth = maxHealth;
            }

            OnRegen?.Invoke(value);
        }
    }
    private void Death(GameObject killerPlayer)
    {
        currentHealth = 0f;

        isDead = true;

        OnDead?.Invoke(killerPlayer);
    }
}
