using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [SerializeField] private float moveSpeed = 5f;
    [SerializeField] public float jumpForce = 10f;
    [SerializeField] private float groundCheckRadius = 0.2f;
    [SerializeField] private LayerMask groundLayer;
    [SerializeField] private float acceleration = 10f;
    [SerializeField] private float deceleration = 10f;
    [SerializeField] private float airControl = 0.5f;
    [SerializeField] public float timeToNextJump = 0.5f;
    [SerializeField] private Transform groundCheck;
    [SerializeField] public InputState inputState;

    private InputManager inputManager;
    public Rigidbody2D rb { get; set; }
    public float timeToJump { get; set; }
    public float MoveInput { get; set; }
    public bool IsGrounded { get; private set; }

    public bool _isFirstPlayer;
    public bool IsFirstPlayer => _isFirstPlayer;

    private void Start()
    {
        Initialize();
    }
    public virtual void Initialize()
    {
        string currentLayer = IsFirstPlayer ? "FirstPlayer" : "SecondPlayer";
        gameObject.layer = LayerMask.NameToLayer(currentLayer);

        rb = GetComponent<Rigidbody2D>();
        inputManager = GetComponent<InputManager>();
    }
    private void Update()
    {
        GroundCheck();
    }
    private void FixedUpdate()
    {
        Movement();
    }
    private void GroundCheck() 
    {
        IsGrounded = Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, groundLayer);

        if (inputState.MoveIsLocked) { return; }

        timeToJump += Time.deltaTime;

        Jump();
    }
    public virtual void Jump()
    {
        if (inputManager.JumpInput > 0f)
        {
            if (IsGrounded && timeToJump >= timeToNextJump)
            {
                timeToJump = 0f;
                rb.velocity = new Vector2(rb.velocity.x, jumpForce);
            }
        }
    }
    public virtual void InputMove()
    {
        MoveInput = inputState.MoveIsLocked ? 0f : inputManager.MoveInput;
    }
    private void Movement() 
    {
        InputMove();

        if (MoveInput != 0)
        {
            float targetSpeed = MoveInput * moveSpeed;
            float speedDifference = targetSpeed - rb.velocity.x;
            float movement = speedDifference * (IsGrounded ? acceleration : acceleration * airControl);
            rb.AddForce(new Vector2(movement, 0));
        }
        else
        {
            float decelerationForce = rb.velocity.x * (IsGrounded ? deceleration : deceleration * airControl);
            rb.AddForce(new Vector2(-decelerationForce, 0));
        }
    }
    private void OnDrawGizmosSelected()
    {
        if (groundCheck != null)
        {
            Gizmos.color = Color.red;
            Gizmos.DrawWireSphere(groundCheck.position, groundCheckRadius);
        }
    }
}