using UnityEngine;

public class InitializeCharacterSkin : MonoBehaviour
{
    [SerializeField] private PlayerController playerController;

    private SpriteRenderer spriteRenderer;
    private Animator animator;
    private void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        animator = GetComponent<Animator>();

        if (CharacterSkinData.Instance == null) { return; }

        SkinData currentSkinData = playerController.IsFirstPlayer ? CharacterSkinData.Instance.FirstCharacterSkin : CharacterSkinData.Instance.SecondCharacterSkin;

        spriteRenderer.sprite = currentSkinData.skinImage;
        animator.runtimeAnimatorController = currentSkinData.skinAnimatorController;
    }
}
