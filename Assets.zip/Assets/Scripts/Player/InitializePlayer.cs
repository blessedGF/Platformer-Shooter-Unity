using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class InitializePlayer : MonoBehaviour
{
    [SerializeField] private GameObject[] playerPrefab;
    [SerializeField] private Transform[] playerSpawnPos;
    [SerializeField] private float timeToStart = 3f;
    [SerializeField] private float timeToSpawnPlayers = 2f;

    private int time;
    public bool GameIsStarted { get; private set; }

    private List<GameObject> playerObjects = new List<GameObject>();

    private void Awake()
    {
        StartCoroutine(SpawnAnimation());
    }
    private IEnumerator SpawnAnimation()
    {
        yield return new WaitForSeconds(timeToSpawnPlayers);

        for (int i = 0; i < playerPrefab.Length; i++)
        {
            GameObject newPlayerPrefab = Instantiate(playerPrefab[i], playerSpawnPos[i].position, Quaternion.identity);
            newPlayerPrefab.GetComponent<InputState>().AddLockMovement("Spawn");
            newPlayerPrefab.GetComponent<PlayerController>()._isFirstPlayer = i == 0;

            playerObjects.Add(newPlayerPrefab);
        }

        time = (int)timeToStart;

        while (time > 0) 
        {
            ScoreTextUpdate.Instance.scoreText.text = time.ToString();

            yield return new WaitForSeconds(1f);
            time -= 1;

            yield return null;
        }

        foreach (var player in playerObjects) 
        {
            player.GetComponent<InputState>().RemoveLockMovement("Spawn");
        }

        GameIsStarted = true;

        ScoreTextUpdate.Instance?.ChangeScoreText?.Invoke();
    }
}
