using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class PlayerHealthAmmoUI : MonoBehaviour
{
    [SerializeField] private PlayerHealth playerHealth;
    [SerializeField] private WeaponSystem weaponSystem;
    [SerializeField] private Image healthImage;
    [SerializeField] private Image ammoImage;

    private void OnEnable()
    {
        playerHealth.OnHit += UpdateHealthUI;
        weaponSystem.OnAmmoUpdate += UpdateAmmoUI;
    }
    private void OnDisable()
    {
        playerHealth.OnHit -= UpdateHealthUI;
        weaponSystem.OnAmmoUpdate -= UpdateAmmoUI;
    }
    private void UpdateHealthUI(float currentHealthValue)
    {
        float targetValue = healthImage.fillAmount - currentHealthValue / playerHealth.maxHealth;
        healthImage.fillAmount = targetValue;
    }
    private void UpdateAmmoUI() 
    {
        float targetValue = (float)weaponSystem.currentAmmoValue / (float)weaponSystem.weaponData.maxAmmo;
        ammoImage.fillAmount = targetValue;
    }
}
