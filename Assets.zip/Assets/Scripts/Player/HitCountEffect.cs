using System;
using System.Collections;
using TMPro;
using UnityEngine;

public class HitCountEffect : MonoBehaviour
{
    [SerializeField] private float durationTime = 1f;
    [SerializeField] private float disappearanceTime = 1f;
    [SerializeField] private TextMeshPro hitText;

    [NonSerialized] public float _damage;
    private float Damage => _damage;
    private void Start()
    {
        StartCoroutine(HitEffect(Damage, new Vector2(UnityEngine.Random.Range(0f, 1f), UnityEngine.Random.Range(0f, 1f))));
    }
    private IEnumerator HitEffect(float _hitDamageValue, Vector2 direction)
    {
        hitText.text = $"-{_hitDamageValue}";

        float alpha = hitText.color.a;

        while (hitText.color.a > 0)
        {
            alpha -= Time.deltaTime * disappearanceTime;
            Color targetColor = new Color(hitText.color.r, hitText.color.g, hitText.color.b, alpha);
            hitText.color = targetColor;

            hitText.transform.localPosition = Vector2.Lerp(hitText.transform.localPosition, direction, Time.deltaTime * durationTime);

            yield return null;
        }

        Destroy(gameObject);
    }
}
