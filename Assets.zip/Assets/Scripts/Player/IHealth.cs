using System;
using UnityEngine;

public interface IHealth
{
    public float currentHealth { get; set; }
    public float maxHealth { get; set; }
    public bool isDead { get; set; }

    public event Action<GameObject> OnDead;
    public event Action<float> OnHit;

    public void RemoveHealth(float value, GameObject attackingPlayer) 
    {
        if (currentHealth > 0f) 
        {
            if (currentHealth - value > 0f) 
            {
                currentHealth -= value;
            }
            else 
            {
                currentHealth = 0f;
                isDead = true;
            }
        }
    }
    public void AddHealth(float value)
    {
        if (currentHealth > 0f)
        {
            if (currentHealth + value < maxHealth)
            {
                currentHealth += value;
            }
            else
            {
                currentHealth = maxHealth;
            }
        }
    }
}
